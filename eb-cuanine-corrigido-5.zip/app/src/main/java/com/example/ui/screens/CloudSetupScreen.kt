package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicRed
import com.example.util.CloudDiagnostics
import com.example.util.CloudStatus
import kotlinx.coroutines.launch

/** Área do Técnico ICT: estado da ligação à nuvem e teste. A sincronização dos dados vem nas versões seguintes. */
@Composable
fun CloudSetupScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CloudStatus?>(null) }
    val configured = CloudDiagnostics.isConfigured(context)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Nuvem da escola", fontSize = 18.sp, fontWeight = FontWeight.Bold)

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Estado da ligação", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = if (configured) {
                        "Configurada. Projecto: ${CloudDiagnostics.projectId() ?: "?"}"
                    } else {
                        "Ainda sem configuração. Falta o ficheiro google-services.json nesta compilação."
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (configured) AcademicEmerald else AcademicRed
                )
                Text(
                    "Esta versão só prepara e testa a ligação. A sincronização de contas, alunos, notas e presenças " +
                        "entra nas versões seguintes, por etapas, para não pôr em risco os dados da escola.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = {
                        running = true
                        result = null
                        scope.launch {
                            result = CloudDiagnostics.testConnection(context)
                            running = false
                        }
                    },
                    enabled = !running,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (running) "A testar..." else "Testar ligação à nuvem", fontWeight = FontWeight.Bold) }
            }
        }

        result?.let { status ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = (if (status.ok) AcademicEmerald else AcademicRed).copy(alpha = 0.12f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = (if (status.ok) "✔ " else "✖ ") + status.message,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (status.ok) AcademicEmerald else AcademicRed,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
    }
}
