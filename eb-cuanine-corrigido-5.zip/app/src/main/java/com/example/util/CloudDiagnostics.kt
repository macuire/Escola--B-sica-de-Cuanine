package com.example.util

import android.content.Context
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

data class CloudStatus(val ok: Boolean, val message: String)

/** Verifica se o app está ligado ao projecto Firebase da escola (base para a sincronização). */
object CloudDiagnostics {

    fun isConfigured(context: Context): Boolean =
        FirebaseApp.getApps(context.applicationContext).isNotEmpty()

    fun projectId(): String? = try {
        FirebaseApp.getInstance().options.projectId
    } catch (e: Exception) {
        null
    }

    private suspend fun <T> Task<T>.awaitResult(): T = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { cont.resume(it) }
        addOnFailureListener { cont.resumeWithException(it) }
    }

    suspend fun testConnection(context: Context): CloudStatus {
        if (!isConfigured(context)) {
            return CloudStatus(
                false,
                "Esta compilação não tem o ficheiro google-services.json. Envie-o para a raiz do repositório no GitHub e compile outra vez."
            )
        }
        return try {
            val auth = FirebaseAuth.getInstance()
            val user = auth.currentUser ?: auth.signInAnonymously().awaitResult().user
                ?: return CloudStatus(false, "Não foi possível iniciar a ligação anónima.")
            val ref = FirebaseFirestore.getInstance().collection("diagnostico").document(user.uid)
            ref.set(mapOf("quando" to System.currentTimeMillis(), "versaoApp" to "1.9")).awaitResult()
            val snapshot = ref.get().awaitResult()
            if (snapshot.exists()) {
                CloudStatus(true, "Ligação à nuvem a funcionar. Projecto: ${projectId() ?: "?"}.")
            } else {
                CloudStatus(false, "A escrita funcionou, mas a leitura não devolveu o registo de teste.")
            }
        } catch (e: FirebaseNetworkException) {
            CloudStatus(false, "Sem Internet, ou o Firebase não está acessível. Verifique os dados móveis ou o Wi-Fi.")
        } catch (e: FirebaseAuthException) {
            CloudStatus(
                false,
                "O Firebase recusou a ligação anónima (${e.errorCode}). Em Authentication → Sign-in method, active o fornecedor Anónimo."
            )
        } catch (e: FirebaseFirestoreException) {
            if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                CloudStatus(false, "As regras do Firestore não permitem o teste. Cole as regras que lhe indiquei no separador Regras e toque em Publicar.")
            } else {
                CloudStatus(false, "Erro do Firestore (${e.code}). Confirme que criou a base de dados Firestore.")
            }
        } catch (e: Exception) {
            CloudStatus(false, "Falhou: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
