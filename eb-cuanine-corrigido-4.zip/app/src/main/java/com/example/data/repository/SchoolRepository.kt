package com.example.data.repository

import com.example.data.dao.SchoolDao
import com.example.data.model.AttendanceRecord
import com.example.data.model.Classroom
import com.example.data.model.FormulaConfig
import com.example.data.model.GradeRecord
import com.example.data.model.PautaLock
import com.example.data.model.SchoolNotice
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.data.model.Teacher
import kotlinx.coroutines.flow.Flow

class SchoolRepository(private val dao: SchoolDao) {

    // Alunos
    val allStudents: Flow<List<Student>> = dao.getAllStudents()
    fun getStudentsByClass(gradeClass: Int, section: String): Flow<List<Student>> =
        dao.getStudentsByClass(gradeClass, section)
    fun getStudentsByCycle(cycle: Int): Flow<List<Student>> = dao.getStudentsByCycle(cycle)
    fun getStudentsByEnrollmentStatus(status: String): Flow<List<Student>> = dao.getStudentsByEnrollmentStatus(status)
    fun searchStudents(query: String): Flow<List<Student>> = dao.searchStudents(query)
    fun getStudentById(id: Long): Flow<Student?> = dao.getStudentById(id)
    suspend fun getStudentByIdDirect(id: Long): Student? = dao.getStudentByIdDirect(id)
    suspend fun getStudentByNumberDirect(studentNumber: String): Student? = dao.getStudentByNumberDirect(studentNumber)
    suspend fun registerStudent(student: Student): Long = dao.insertStudent(student)
    suspend fun updateStudent(student: Student) = dao.updateStudent(student)
    suspend fun updateEnrollmentStatus(studentId: Long, status: String, transferDest: String?, reason: String?) =
        dao.updateEnrollmentStatus(studentId, status, transferDest, reason)
    suspend fun deleteStudent(student: Student) = dao.deleteStudent(student)
    suspend fun importStudents(students: List<Student>) = dao.insertStudents(students)

    /** Apaga alunos, notas, presenças e notícias. Mantém classes, disciplinas e fórmulas. */
    suspend fun clearSchoolData() {
        dao.deleteAllGrades()
        dao.deleteAllAttendance()
        dao.deleteAllNotices()
        dao.deleteAllStudents()
    }

    // Turmas
    val allClassrooms: Flow<List<Classroom>> = dao.getAllClassrooms()
    suspend fun addClassroom(classroom: Classroom): Long = dao.insertClassroom(classroom)
    suspend fun updateClassroom(classroom: Classroom) = dao.updateClassroom(classroom)
    suspend fun updateSubject(subject: Subject) = dao.updateSubject(subject)
    suspend fun deleteSubject(subject: Subject) = dao.deleteSubject(subject)
    suspend fun importStudentsSafe(students: List<Student>): List<Long> = dao.insertStudentsSafe(students)
    suspend fun deleteClassroom(classroom: Classroom) = dao.deleteClassroom(classroom)

    // Disciplinas
    val allSubjects: Flow<List<Subject>> = dao.getAllSubjects()
    suspend fun addSubject(subject: Subject): Long = dao.insertSubject(subject)

    // Pautas / Notas
    val allGrades: Flow<List<GradeRecord>> = dao.getAllGrades()
    fun getGradesForStudent(studentId: Long, schoolYear: Int = 2026): Flow<List<GradeRecord>> =
        dao.getGradesForStudent(studentId, schoolYear)

    fun getGradesForClassAndSubject(studentIds: List<Long>, subjectId: Long, term: Int): Flow<List<GradeRecord>> =
        dao.getGradesForClassAndSubject(studentIds, subjectId, term)

    suspend fun getGradeDirect(studentId: Long, subjectId: Long, term: Int, schoolYear: Int = 2026): GradeRecord? =
        dao.getGradeDirect(studentId, subjectId, term, schoolYear)

    suspend fun saveGrade(grade: GradeRecord): Long = dao.insertOrUpdateGrade(grade)
    suspend fun saveGrades(grades: List<GradeRecord>) = dao.insertGrades(grades)

    // Governação e Trava de Pautas (Pós-Conselho)
    val allPautaLocks: Flow<List<PautaLock>> = dao.getAllPautaLocks()
    fun getPautaLock(gradeClass: Int, section: String, subjectId: Long, term: Int): Flow<PautaLock?> =
        dao.getPautaLock(gradeClass, section, subjectId, term)
    suspend fun getPautaLockDirect(gradeClass: Int, section: String, subjectId: Long, term: Int): PautaLock? =
        dao.getPautaLockDirect(gradeClass, section, subjectId, term)
    suspend fun setPautaLock(lock: PautaLock) = dao.insertOrUpdateLock(lock)

    // Notícias e Avisos (Google Notícias Style)
    val allNotices: Flow<List<SchoolNotice>> = dao.getAllNotices()
    suspend fun addNotice(notice: SchoolNotice): Long = dao.insertNotice(notice)

    // Assiduidade / Presenças
    fun getAttendanceForClassAndDate(studentIds: List<Long>, subjectId: Long, date: String): Flow<List<AttendanceRecord>> =
        dao.getAttendanceForClassAndDate(studentIds, subjectId, date)
    fun getAttendanceForStudent(studentId: Long): Flow<List<AttendanceRecord>> =
        dao.getAttendanceForStudent(studentId)
    suspend fun saveAttendance(attendance: AttendanceRecord) =
        dao.insertOrUpdateAttendance(attendance)
    suspend fun saveAttendances(attendances: List<AttendanceRecord>) =
        dao.insertAttendances(attendances)

    // Fórmulas SNE
    val allFormulaConfigs: Flow<List<FormulaConfig>> = dao.getAllFormulaConfigs()
    suspend fun getFormulaConfig(cycle: Int): FormulaConfig? = dao.getFormulaConfigDirect(cycle)
    suspend fun saveFormulaConfig(config: FormulaConfig) = dao.insertOrUpdateFormula(config)

    // Professores (Fase 2 - Base de Dados)
    val allTeachers: Flow<List<Teacher>> = dao.getAllTeachers()
    suspend fun addTeacher(teacher: Teacher): Long = dao.insertTeacher(teacher)
    suspend fun updateTeacher(teacher: Teacher) = dao.updateTeacher(teacher)
    suspend fun deleteTeacher(teacher: Teacher) = dao.deleteTeacher(teacher)
    suspend fun countTeachers(): Int = dao.countTeachers()
}
