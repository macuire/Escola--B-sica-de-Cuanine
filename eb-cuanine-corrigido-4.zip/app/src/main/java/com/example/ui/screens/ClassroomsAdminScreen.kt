package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Classroom
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.ui.components.EditField
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicRed
import com.example.util.SubjectRules

private data class ClassDialog(val existing: Classroom?)
private data class SubjectDialog(val existing: Subject?)

/** Turmas (varias por classe, da 1.ª à 12.ª) e disciplinas (com as classes em que se lecciona). Só ICT e Direcção. */
@Composable
fun ClassroomsAdminScreen(
    classrooms: List<Classroom>,
    subjects: List<Subject>,
    students: List<Student>,
    onSaveClassroom: (Classroom?, Int, String, String, String, String, (String?) -> Unit) -> Unit,
    onDeleteClassroom: (Classroom, (String?) -> Unit) -> Unit,
    onSaveSubject: (Subject?, String, String, Set<Int>, (String?) -> Unit) -> Unit,
    onDeleteSubject: (Subject, (String?) -> Unit) -> Unit,
    onAddSuggestions: ((String?) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    var tab by remember { mutableStateOf(0) }
    var classDialog by remember { mutableStateOf<ClassDialog?>(null) }
    var subjectDialog by remember { mutableStateOf<SubjectDialog?>(null) }

    Column(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text("Turmas e Disciplinas", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                "${classrooms.size} turmas • ${subjects.size} disciplinas",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Turmas") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Disciplinas") })
        }

        if (tab == 0) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Button(onClick = { classDialog = ClassDialog(null) }, shape = RoundedCornerShape(12.dp)) {
                        Text("+ Nova turma", fontWeight = FontWeight.Bold)
                    }
                }
                items(
                    classrooms.sortedWith(compareBy({ it.grade }, { it.section })),
                    key = { it.id }
                ) { c ->
                    val count = students.count { it.gradeClass == c.grade && it.section == c.section }
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().clickable { classDialog = ClassDialog(c) }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("${c.grade}.ª '${c.section}'  •  $count alunos", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Sala: ${c.roomName}", fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Director de turma: ${c.classTeacher}", fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Turno: ${c.shift}", fontSize = 12.sp, color = AcademicEmerald)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { subjectDialog = SubjectDialog(null) }, shape = RoundedCornerShape(12.dp)) {
                            Text("+ Nova disciplina", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { onAddSuggestions { } },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Acrescentar sugestão de disciplinas do secundário", fontSize = 12.sp) }
                    Text(
                        "É uma sugestão. Confirme as disciplinas e as classes com o plano curricular oficial e edite-as aqui.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                items(subjects.sortedBy { it.name }, key = { it.id }) { sj ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().clickable { subjectDialog = SubjectDialog(sj) }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(sj.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Código: ${sj.code}", fontSize = 12.sp)
                            Text("Classes: " + SubjectRules.describe(sj.applicableCycles), fontSize = 12.sp, color = AcademicEmerald)
                        }
                    }
                }
            }
        }
    }

    classDialog?.let { dialog ->
        ClassroomEditDialog(
            existing = dialog.existing,
            hasStudents = dialog.existing != null && students.any {
                it.gradeClass == dialog.existing.grade && it.section == dialog.existing.section
            },
            onSave = onSaveClassroom,
            onDelete = onDeleteClassroom,
            onDismiss = { classDialog = null }
        )
    }
    subjectDialog?.let { dialog ->
        SubjectEditDialog(
            existing = dialog.existing,
            onSave = onSaveSubject,
            onDelete = onDeleteSubject,
            onDismiss = { subjectDialog = null }
        )
    }
}

@Composable
private fun ClassroomEditDialog(
    existing: Classroom?,
    hasStudents: Boolean,
    onSave: (Classroom?, Int, String, String, String, String, (String?) -> Unit) -> Unit,
    onDelete: (Classroom, (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var grade by remember { mutableStateOf(existing?.grade ?: 1) }
    var section by remember { mutableStateOf(existing?.section ?: "") }
    var room by remember { mutableStateOf(existing?.roomName ?: "") }
    var teacher by remember { mutableStateOf(existing?.classTeacher ?: "") }
    var shift by remember { mutableStateOf(existing?.shift ?: "Manhã") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nova turma" else "Editar turma", fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (hasStudents) {
                    Text(
                        "Esta turma tem alunos: a classe e a letra não se podem mudar. Pode mudar a sala, o director e o turno.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text("Classe", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    (1..12).forEach { g ->
                        FilterChip(
                            selected = grade == g,
                            enabled = !hasStudents,
                            onClick = { grade = g; error = null },
                            label = { Text("$g.ª") }
                        )
                    }
                }
                EditField("Turma (A, B, C...)", section) { if (!hasStudents) { section = it; error = null } }
                EditField("Sala (ex.: Sala 3 - Bloco B)", room) { room = it; error = null }
                EditField("Director de turma", teacher) { teacher = it; error = null }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Manhã", "Tarde", "Noite").forEach { t ->
                        FilterChip(selected = shift == t, onClick = { shift = t }, label = { Text(t) })
                    }
                }
                error?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val sectionToSend = if (existing != null && hasStudents) existing.section else section
                onSave(existing, grade, sectionToSend, room, teacher, shift) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                if (existing != null) {
                    TextButton(onClick = {
                        onDelete(existing) { result -> if (result == null) onDismiss() else error = result }
                    }) { Text("Apagar", color = AcademicRed) }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )
}

@Composable
private fun SubjectEditDialog(
    existing: Subject?,
    onSave: (Subject?, String, String, Set<Int>, (String?) -> Unit) -> Unit,
    onDelete: (Subject, (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var code by remember { mutableStateOf(existing?.code ?: "") }
    var classes by remember { mutableStateOf(existing?.let { SubjectRules.gradesOf(it.applicableCycles).toSet() } ?: emptySet()) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nova disciplina" else "Editar disciplina", fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                EditField("Nome da disciplina", name) { name = it; error = null }
                EditField("Código curto (opcional)", code) { code = it; error = null }
                Text("Classes em que se lecciona", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    OutlinedButton(onClick = { classes = classes + (1..6).toSet() }) { Text("1.ª–6.ª", fontSize = 11.sp) }
                    OutlinedButton(onClick = { classes = classes + (7..9).toSet() }) { Text("7.ª–9.ª", fontSize = 11.sp) }
                    OutlinedButton(onClick = { classes = classes + (10..12).toSet() }) { Text("10.ª–12.ª", fontSize = 11.sp) }
                    OutlinedButton(onClick = { classes = emptySet() }) { Text("Limpar", fontSize = 11.sp) }
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    (1..12).forEach { g ->
                        FilterChip(
                            selected = g in classes,
                            onClick = { classes = if (g in classes) classes - g else classes + g; error = null },
                            label = { Text("$g.ª") }
                        )
                    }
                }
                error?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(existing, name, code, classes) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("Guardar") }
        },
        dismissButton = {
            Row {
                if (existing != null) {
                    TextButton(onClick = { confirmDelete = true }) { Text("Apagar", color = AcademicRed) }
                }
                TextButton(onClick = onDismiss) { Text("Cancelar") }
            }
        }
    )

    if (confirmDelete && existing != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Apagar disciplina", fontSize = 16.sp) },
            text = { Text("Apagar \"${existing.name}\" apaga também todas as notas e presenças dessa disciplina. Continuar?", fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(existing) { result -> if (result == null) onDismiss() else error = result }
                }) { Text("Apagar", color = AcademicRed) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
}
