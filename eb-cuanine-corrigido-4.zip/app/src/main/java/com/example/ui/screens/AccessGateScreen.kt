package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.RecoveryCodeShownDialog
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent

private const val PORTAL_FAMILY = "FAMILIA"
private const val PORTAL_STAFF = "FUNCIONARIOS"

/**
 * Ecrã inicial: o utilizador escolhe a janela (Estudantes e Encarregados, ou Funcionários),
 * entra com contacto + PIN ou faz o cadastro. Os cadastros ficam pendentes até o Técnico ICT aprovar.
 */
@Composable
fun AccessGateScreen(
    needsIctSetup: Boolean?,
    onLogin: (phone: String, pin: String, portal: String, onResult: (String?) -> Unit) -> Unit,
    onRegister: (
        fullName: String,
        phone: String,
        accountType: String,
        studentNumber: String,
        jobTitle: String,
        pin: String,
        pinConfirm: String,
        onResult: (String?) -> Unit
    ) -> Unit,
    onRegisterFirstIct: (
        fullName: String,
        phone: String,
        pin: String,
        pinConfirm: String,
        onResult: (error: String?, recoveryCode: String?) -> Unit
    ) -> Unit,
    onRecoverIct: (
        phone: String,
        code: String,
        newPin: String,
        newPinConfirm: String,
        onResult: (String?) -> Unit
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    var portal by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = portal != null) { portal = null }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CuanineNavy)
    ) {
        val current = portal
        if (current == null) {
            PortalChooser(onChoose = { portal = it })
        } else {
            PortalForms(
                portal = current,
                needsIctSetup = needsIctSetup,
                onBack = { portal = null },
                onLogin = onLogin,
                onRegister = onRegister,
                onRegisterFirstIct = onRegisterFirstIct,
                onRecoverIct = onRecoverIct
            )
        }
    }
}

@Composable
private fun PortalChooser(onChoose: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(GoldAccent),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.eb_cuanine_logo),
                contentDescription = "Emblema EB Cuanine",
                modifier = Modifier
                    .size(88.dp)
                    .clip(CircleShape)
            )
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "Escola Básica de Cuanine",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Distrito da Manhiça • Província de Maputo",
            color = GoldAccent,
            fontSize = 12.sp
        )
        Spacer(modifier = Modifier.height(28.dp))
        Text(
            text = "Escolha a sua janela de acesso",
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(14.dp))

        PortalCard(
            title = "Estudantes e Encarregados",
            description = "Notas, faltas, comunicados, notícias, estatísticas e quadro de honra.",
            accent = AcademicEmerald,
            icon = { Icon(Icons.Default.School, contentDescription = null, tint = Color.White) },
            onClick = { onChoose(PORTAL_FAMILY) }
        )
        Spacer(modifier = Modifier.height(14.dp))
        PortalCard(
            title = "Funcionários",
            description = "Docentes e não docentes: pautas, presenças, matrículas e gestão escolar.",
            accent = GoldAccent,
            icon = { Icon(Icons.Default.Badge, contentDescription = null, tint = Color.White) },
            onClick = { onChoose(PORTAL_STAFF) }
        )
    }
}

@Composable
private fun PortalCard(
    title: String,
    description: String,
    accent: Color,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.10f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accent),
                contentAlignment = Alignment.Center
            ) { icon() }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 12.sp
                )
            }
            Text(text = "❯", color = accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PortalForms(
    portal: String,
    needsIctSetup: Boolean?,
    onBack: () -> Unit,
    onLogin: (String, String, String, (String?) -> Unit) -> Unit,
    onRegister: (String, String, String, String, String, String, String, (String?) -> Unit) -> Unit,
    onRegisterFirstIct: (String, String, String, String, (String?, String?) -> Unit) -> Unit,
    onRecoverIct: (String, String, String, String, (String?) -> Unit) -> Unit
) {
    val isFamily = portal == PORTAL_FAMILY
    var tab by remember { mutableStateOf(0) } // 0 = Entrar, 1 = Cadastrar-se
    var ictSetupMode by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) } // mensagem de sucesso

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }
            Column {
                Text(
                    text = if (isFamily) "Estudantes e Encarregados" else "Funcionários",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isFamily) "Acesso a assuntos dos estudantes" else "Docentes e não docentes",
                    color = GoldAccent,
                    fontSize = 12.sp
                )
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (ictSetupMode) {
                    IctSetupForm(
                        onCancel = { ictSetupMode = false },
                        onRegisterFirstIct = onRegisterFirstIct,
                        onDone = {
                            ictSetupMode = false
                            tab = 0
                            notice = "Conta do Técnico ICT criada. Entre com o seu contacto e PIN."
                        }
                    )
                } else {
                    TabRow(selectedTabIndex = tab) {
                        Tab(
                            selected = tab == 0,
                            onClick = { tab = 0 },
                            text = { Text("Entrar") }
                        )
                        Tab(
                            selected = tab == 1,
                            onClick = { tab = 1 },
                            text = { Text("Cadastrar-se") }
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))

                    val successNotice = notice
                    if (successNotice != null) {
                        MessageBox(text = successNotice, isError = false)
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (tab == 0) {
                        LoginForm(
                            portal = portal,
                            onLogin = onLogin,
                            onRecoverIct = onRecoverIct,
                            onTypingClearNotice = { notice = null }
                        )
                        if (!isFamily && needsIctSetup == true) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = GoldAccent.copy(alpha = 0.12f)
                                )
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "Primeiro acesso",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "Ainda não existe Técnico ICT neste aparelho. Crie a conta do Técnico ICT para poder aprovar os restantes cadastros.",
                                        fontSize = 12.sp
                                    )
                                    TextButton(onClick = { ictSetupMode = true }) {
                                        Text("Configurar Técnico ICT")
                                    }
                                }
                            }
                        }
                    } else {
                        RegisterForm(
                            isFamily = isFamily,
                            onRegister = onRegister,
                            onDone = {
                                tab = 0
                                notice = "Cadastro enviado! Aguarde a aprovação do Técnico ICT. Depois poderá entrar com o seu contacto e PIN."
                            }
                        )
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = "Os cadastros são analisados e geridos pelo Técnico ICT da escola.",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 11.sp
        )
    }
}

@Composable
private fun LoginForm(
    portal: String,
    onLogin: (String, String, String, (String?) -> Unit) -> Unit,
    onRecoverIct: (String, String, String, String, (String?) -> Unit) -> Unit,
    onTypingClearNotice: () -> Unit
) {
    var showForgot by remember { mutableStateOf(false) }
    var phone by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    FormField(
        label = "Contacto (telemóvel)",
        value = phone,
        onChange = { phone = it; error = null; onTypingClearNotice() },
        keyboardType = KeyboardType.Phone
    )
    Spacer(modifier = Modifier.height(8.dp))
    FormField(
        label = "PIN",
        value = pin,
        onChange = { pin = it.filter { c -> c.isDigit() }.take(6); error = null },
        keyboardType = KeyboardType.NumberPassword,
        secret = true
    )
    error?.let {
        Spacer(modifier = Modifier.height(8.dp))
        MessageBox(text = it, isError = true)
    }
    Spacer(modifier = Modifier.height(12.dp))
    Button(
        onClick = {
            busy = true
            onLogin(phone, pin, portal) { result ->
                busy = false
                error = result
            }
        },
        enabled = !busy,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(if (busy) "A verificar..." else "Entrar", fontWeight = FontWeight.Bold)
    }
    TextButton(onClick = { showForgot = true }) { Text("Esqueci o PIN") }

    if (showForgot) {
        ForgotPinDialog(
            isFamily = portal == PORTAL_FAMILY,
            onRecoverIct = onRecoverIct,
            onDismiss = { showForgot = false }
        )
    }
}

@Composable
private fun ForgotPinDialog(
    isFamily: Boolean,
    onRecoverIct: (String, String, String, String, (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var showIctForm by remember { mutableStateOf(false) }
    var phone by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Esqueci o PIN", fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (done) {
                    MessageBox(text = "PIN redefinido. Já pode entrar com o novo PIN.", isError = false)
                } else {
                    Text(
                        "Peça ao Técnico ICT da escola para repor o seu PIN (em Contas e Cadastros). " +
                            "Depois de entrar, pode mudá-lo no menu, em \"Alterar o meu PIN\".",
                        fontSize = 13.sp
                    )
                    if (!isFamily) {
                        if (!showIctForm) {
                            TextButton(onClick = { showIctForm = true }) {
                                Text("Sou o Técnico ICT e tenho o código de recuperação")
                            }
                        } else {
                            FormField(label = "Contacto (telemóvel)", value = phone, onChange = { phone = it; error = null }, keyboardType = KeyboardType.Phone)
                            FormField(label = "Código de recuperação", value = code, onChange = { code = it; error = null })
                            FormField(label = "Novo PIN (4 a 6 dígitos)", value = newPin, onChange = { newPin = it.filter { c -> c.isDigit() }.take(6); error = null }, keyboardType = KeyboardType.NumberPassword, secret = true)
                            FormField(label = "Repetir o novo PIN", value = confirm, onChange = { confirm = it.filter { c -> c.isDigit() }.take(6); error = null }, keyboardType = KeyboardType.NumberPassword, secret = true)
                            error?.let { MessageBox(text = it, isError = true) }
                            Button(
                                onClick = {
                                    onRecoverIct(phone, code, newPin, confirm) { result ->
                                        if (result == null) done = true else error = result
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Recuperar acesso", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
private fun RegisterForm(
    isFamily: Boolean,
    onRegister: (String, String, String, String, String, String, String, (String?) -> Unit) -> Unit,
    onDone: () -> Unit
) {
    var type by remember { mutableStateOf(if (isFamily) "ESTUDANTE" else "DOCENTE") }
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var studentNumber by remember { mutableStateOf("") }
    var jobTitle by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (isFamily) {
            FilterChip(selected = type == "ESTUDANTE", onClick = { type = "ESTUDANTE" }, label = { Text("Estudante") })
            FilterChip(selected = type == "ENCARREGADO", onClick = { type = "ENCARREGADO" }, label = { Text("Encarregado") })
        } else {
            FilterChip(selected = type == "DOCENTE", onClick = { type = "DOCENTE" }, label = { Text("Docente") })
            FilterChip(selected = type == "NAO_DOCENTE", onClick = { type = "NAO_DOCENTE" }, label = { Text("Não docente") })
        }
    }
    Spacer(modifier = Modifier.height(10.dp))
    FormField(label = "Nome completo", value = fullName, onChange = { fullName = it; error = null })
    Spacer(modifier = Modifier.height(8.dp))
    FormField(
        label = "Contacto (telemóvel)",
        value = phone,
        onChange = { phone = it; error = null },
        keyboardType = KeyboardType.Phone
    )
    Spacer(modifier = Modifier.height(8.dp))
    if (isFamily) {
        FormField(
            label = if (type == "ESTUDANTE") "O meu n.º de processo (ex.: EBC-2026-001)" else "N.º de processo do educando (ex.: EBC-2026-001)",
            value = studentNumber,
            onChange = { studentNumber = it; error = null }
        )
    } else {
        FormField(
            label = if (type == "DOCENTE") "Função / disciplinas (ex.: Professor de Matemática)" else "Função / sector (ex.: Secretaria)",
            value = jobTitle,
            onChange = { jobTitle = it; error = null }
        )
    }
    Spacer(modifier = Modifier.height(8.dp))
    FormField(
        label = "Criar PIN (4 a 6 dígitos)",
        value = pin,
        onChange = { pin = it.filter { c -> c.isDigit() }.take(6); error = null },
        keyboardType = KeyboardType.NumberPassword,
        secret = true
    )
    Spacer(modifier = Modifier.height(8.dp))
    FormField(
        label = "Repetir PIN",
        value = pinConfirm,
        onChange = { pinConfirm = it.filter { c -> c.isDigit() }.take(6); error = null },
        keyboardType = KeyboardType.NumberPassword,
        secret = true
    )
    error?.let {
        Spacer(modifier = Modifier.height(8.dp))
        MessageBox(text = it, isError = true)
    }
    Spacer(modifier = Modifier.height(12.dp))
    Button(
        onClick = {
            busy = true
            onRegister(fullName, phone, type, studentNumber, jobTitle, pin, pinConfirm) { result ->
                busy = false
                if (result == null) onDone() else error = result
            }
        },
        enabled = !busy,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(if (busy) "A enviar..." else "Enviar cadastro", fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun IctSetupForm(
    onCancel: () -> Unit,
    onRegisterFirstIct: (String, String, String, String, (String?, String?) -> Unit) -> Unit,
    onDone: () -> Unit
) {
    var recoveryCode by remember { mutableStateOf<String?>(null) }
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Text(text = "Configurar Técnico ICT", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    Text(
        text = "Esta conta aprova e gere todos os cadastros. Guarde bem o PIN.",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(10.dp))
    FormField(label = "Nome completo", value = fullName, onChange = { fullName = it; error = null })
    Spacer(modifier = Modifier.height(8.dp))
    FormField(
        label = "Contacto (telemóvel)",
        value = phone,
        onChange = { phone = it; error = null },
        keyboardType = KeyboardType.Phone
    )
    Spacer(modifier = Modifier.height(8.dp))
    FormField(
        label = "Criar PIN (4 a 6 dígitos)",
        value = pin,
        onChange = { pin = it.filter { c -> c.isDigit() }.take(6); error = null },
        keyboardType = KeyboardType.NumberPassword,
        secret = true
    )
    Spacer(modifier = Modifier.height(8.dp))
    FormField(
        label = "Repetir PIN",
        value = pinConfirm,
        onChange = { pinConfirm = it.filter { c -> c.isDigit() }.take(6); error = null },
        keyboardType = KeyboardType.NumberPassword,
        secret = true
    )
    error?.let {
        Spacer(modifier = Modifier.height(8.dp))
        MessageBox(text = it, isError = true)
    }
    Spacer(modifier = Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = onCancel) { Text("Cancelar") }
        Button(
            onClick = {
                busy = true
                onRegisterFirstIct(fullName, phone, pin, pinConfirm) { result, code ->
                    busy = false
                    if (result == null && code != null) {
                        recoveryCode = code
                    } else {
                        error = result ?: "Não foi possível criar a conta."
                    }
                }
            },
            enabled = !busy,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy),
            modifier = Modifier.weight(1f)
        ) {
            Text(if (busy) "A criar..." else "Criar conta ICT", fontWeight = FontWeight.Bold)
        }
    }

    recoveryCode?.let { shownCode ->
        RecoveryCodeShownDialog(code = shownCode, onDone = onDone)
    }
}

@Composable
private fun FormField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    keyboardType: KeyboardType = KeyboardType.Text,
    secret: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, fontSize = 12.sp) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun MessageBox(text: String, isError: Boolean) {
    val color = if (isError) AcademicRed else AcademicGreen
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(10.dp)
    ) {
        Text(text = text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
