package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Classroom
import com.example.data.model.GradeRecord
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.GoldAccent
import com.example.util.AppFlags
import com.example.util.BackupManager
import com.example.util.PautaExcel
import com.example.util.XlsxWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val CSV_TEMPLATE =
    "\uFEFFNome completo;Sexo;Data de nascimento;Classe;Turma;Encarregado;Contacto;Tipo de documento;N.º do documento\n" +
        "Maria José Cossa;F;2016-03-21;2;A;João Cossa;+258 84 123 4567;Cédula Pessoal;\n"

private const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

/** Área do Técnico ICT: cópias de segurança (com palavra-passe), restauro, limpeza, importação e pautas em Excel. */
@Composable
fun DataAdminScreen(
    classrooms: List<Classroom>,
    students: List<Student>,
    subjects: List<Subject>,
    grades: List<GradeRecord>,
    onClearDemo: ((String?) -> Unit) -> Unit,
    onOpenImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var lastBackup by remember { mutableLongStateOf(AppFlags.lastBackup(context)) }
    var busy by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var backupPassword by remember { mutableStateOf("") }
    var backupPasswordConfirm by remember { mutableStateOf("") }
    var backupError by remember { mutableStateOf<String?>(null) }
    var pendingBackupPassword by remember { mutableStateOf<String?>(null) }
    var pendingRestoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var restoreNeedsPassword by remember { mutableStateOf(false) }
    var restorePassword by remember { mutableStateOf("") }
    var restoredDone by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }
    var clearConfirmText by remember { mutableStateOf("") }
    var excelClassId by remember { mutableStateOf<Long?>(null) }
    var excelTerm by remember { mutableStateOf(1) }

    fun toast(text: String) = Toast.makeText(context, text, Toast.LENGTH_LONG).show()

    val backupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            val password = pendingBackupPassword
            scope.launch {
                busy = true
                val error = withContext(Dispatchers.IO) {
                    try {
                        val out = context.contentResolver.openOutputStream(uri)
                            ?: throw IllegalStateException("sem ficheiro")
                        BackupManager.createBackup(context, out, password)
                        null
                    } catch (e: Exception) {
                        "Não foi possível criar a cópia de segurança."
                    }
                }
                busy = false
                pendingBackupPassword = null
                if (error == null) {
                    lastBackup = AppFlags.lastBackup(context)
                    toast(if (password.isNullOrEmpty()) "Cópia guardada (sem palavra-passe)." else "Cópia protegida guardada.")
                } else {
                    toast(error)
                }
            }
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                restoreNeedsPassword = withContext(Dispatchers.IO) {
                    try { BackupManager.isEncrypted(context, uri) } catch (e: Exception) { false }
                }
                restorePassword = ""
                pendingRestoreUri = uri
            }
        }
    }

    val templateLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(CSV_TEMPLATE.toByteArray(Charsets.UTF_8))
                }
                toast("Modelo guardado. Preencha-o no Excel ou no WPS.")
            } catch (e: Exception) {
                toast("Não foi possível guardar o modelo.")
            }
        }
    }

    val excelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(XLSX_MIME)
    ) { uri ->
        val classroom = classrooms.firstOrNull { it.id == excelClassId }
        if (uri != null && classroom != null) {
            val term = excelTerm
            scope.launch {
                busy = true
                val error = withContext(Dispatchers.IO) {
                    try {
                        val sheets = PautaExcel.build(classroom, term, students, subjects, grades)
                        val out = context.contentResolver.openOutputStream(uri)
                            ?: throw IllegalStateException("sem ficheiro")
                        XlsxWriter.write(out, sheets)
                        null
                    } catch (e: Exception) {
                        "Não foi possível criar o ficheiro Excel."
                    }
                }
                busy = false
                toast(error ?: "Pauta em Excel guardada. Abra-a no Excel ou no WPS.")
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Dados e Cópias de Segurança", fontSize = 18.sp, fontWeight = FontWeight.Bold)

        // --- Cópia de segurança ---
        SectionCard(title = "Cópia de segurança") {
            Text(
                "Guarda num só ficheiro todos os dados: alunos, notas, presenças, contas, organograma e fotografias. " +
                    "Proteja-a com palavra-passe: se o ficheiro ou o telemóvel forem roubados, ninguém consegue ler os dados. " +
                    "Guarde a cópia fora do telemóvel (Drive, cartão de memória).",
                fontSize = 12.sp
            )
            val lastText = if (lastBackup == 0L) {
                "Última cópia: ainda não foi feita nenhuma."
            } else {
                "Última cópia: " + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.ROOT).format(Date(lastBackup))
            }
            Text(
                lastText,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (lastBackup == 0L) AcademicRed else AcademicEmerald
            )
            Button(
                onClick = {
                    backupPassword = ""
                    backupPasswordConfirm = ""
                    backupError = null
                    showBackupDialog = true
                },
                enabled = !busy,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "A trabalhar..." else "Criar cópia de segurança", fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { restoreLauncher.launch(arrayOf("*/*")) },
                enabled = !busy,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Restaurar de uma cópia", fontWeight = FontWeight.Bold) }
            Text(
                "O app guarda também, sozinho, uma cópia das 3 últimas vezes em que importou, limpou ou restaurou dados.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // --- Pautas em Excel ---
        SectionCard(title = "Pautas em Excel") {
            Text(
                "Escolha a turma e o trimestre. O app cria um ficheiro .xlsx com uma folha por disciplina, " +
                    "com os alunos, as notas lançadas e as médias. Abre no Excel e no WPS.",
                fontSize = 12.sp
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                classrooms.sortedWith(compareBy({ it.grade }, { it.section })).forEach { c ->
                    FilterChip(
                        selected = excelClassId == c.id,
                        onClick = { excelClassId = c.id },
                        label = { Text("${c.grade}.ª ${c.section}") }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(1, 2, 3).forEach { t ->
                    FilterChip(selected = excelTerm == t, onClick = { excelTerm = t }, label = { Text("$t.º trimestre") })
                }
            }
            Button(
                onClick = {
                    val classroom = classrooms.firstOrNull { it.id == excelClassId }
                    if (classroom == null) {
                        toast("Escolha a turma.")
                    } else {
                        excelLauncher.launch("pauta-${classroom.grade}a-${classroom.section}-T$excelTerm.xlsx")
                    }
                },
                enabled = !busy,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AcademicEmerald),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Gerar pauta em Excel", fontWeight = FontWeight.Bold) }
        }

        // --- Dados de demonstração ---
        SectionCard(title = "Dados de demonstração") {
            Text(
                "O app traz alunos, professores e notícias de exemplo. Antes de usar com a escola real, apague-os. " +
                    "Isto apaga TODOS os alunos, notas, presenças e notícias, e os professores sem conta. " +
                    "Mantém as classes, as disciplinas, as contas e o organograma. O app faz uma cópia automática antes de apagar.",
                fontSize = 12.sp
            )
            Button(
                onClick = { clearConfirmText = ""; showClearDialog = true },
                enabled = !busy,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AcademicRed),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Limpar dados de demonstração", fontWeight = FontWeight.Bold) }
        }

        // --- Alunos reais ---
        SectionCard(title = "Importar os alunos reais") {
            Text(
                "1. Descarregue o modelo e preencha-o no Excel ou no WPS (uma linha por aluno).\n" +
                    "2. Abra a importação, escolha o ficheiro (.xlsx ou .csv), confira as colunas e confirme.\n" +
                    "A importação é feita em blocos pequenos, faz antes uma cópia automática, ignora alunos que já existem " +
                    "(nunca os substitui) e aceita até 3000 linhas e 15 MB de cada vez.",
                fontSize = 12.sp
            )
            OutlinedButton(
                onClick = { templateLauncher.launch("modelo-alunos-eb-cuanine.csv") },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Descarregar modelo de folha (CSV)", fontWeight = FontWeight.Bold) }
            Button(
                onClick = onOpenImport,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Abrir a importação (Excel / WPS)", fontWeight = FontWeight.Bold) }
        }
        Spacer(modifier = Modifier.height(8.dp))
    }

    // Criar cópia: palavra-passe opcional
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("Proteger a cópia", fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Escreva uma palavra-passe de pelo menos 8 caracteres. Sem ela, a cópia não se consegue restaurar, " +
                            "por isso guarde-a num sítio seguro.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = backupPassword,
                        onValueChange = { backupPassword = it; backupError = null },
                        label = { Text("Palavra-passe") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = backupPasswordConfirm,
                        onValueChange = { backupPasswordConfirm = it; backupError = null },
                        label = { Text("Repetir a palavra-passe") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                    backupError?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (backupPassword.length < 8) {
                        backupError = "A palavra-passe deve ter pelo menos 8 caracteres."
                    } else if (backupPassword != backupPasswordConfirm) {
                        backupError = "As duas palavras-passe não coincidem."
                    } else {
                        pendingBackupPassword = backupPassword
                        showBackupDialog = false
                        backupLauncher.launch(
                            "eb-cuanine-backup-" + SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date()) + ".zip"
                        )
                    }
                }) { Text("Criar protegida") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        pendingBackupPassword = null
                        showBackupDialog = false
                        backupLauncher.launch(
                            "eb-cuanine-backup-" + SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date()) + ".zip"
                        )
                    }) { Text("Sem palavra-passe") }
                    TextButton(onClick = { showBackupDialog = false }) { Text("Cancelar") }
                }
            }
        )
    }

    // Confirmação do restauro
    pendingRestoreUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingRestoreUri = null },
            title = { Text("Restaurar cópia de segurança", fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Isto substitui TODOS os dados actuais pelos da cópia escolhida (o app guarda antes uma cópia automática). " +
                            "No fim, o app fecha-se e tem de o abrir outra vez.",
                        fontSize = 13.sp
                    )
                    if (restoreNeedsPassword) {
                        OutlinedTextField(
                            value = restorePassword,
                            onValueChange = { restorePassword = it },
                            label = { Text("Palavra-passe da cópia") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val password = if (restoreNeedsPassword) restorePassword else null
                    pendingRestoreUri = null
                    scope.launch {
                        busy = true
                        val error = withContext(Dispatchers.IO) {
                            try {
                                val input = context.contentResolver.openInputStream(uri)
                                    ?: throw BackupManager.BackupException("Não foi possível abrir o ficheiro.")
                                input.use { BackupManager.restore(context, it, password) }
                                null
                            } catch (e: BackupManager.BackupException) {
                                e.message ?: "Cópia inválida."
                            } catch (e: Exception) {
                                "Não foi possível restaurar a cópia."
                            }
                        }
                        busy = false
                        if (error == null) restoredDone = true else toast(error)
                    }
                }) { Text("Restaurar", color = AcademicRed) }
            },
            dismissButton = { TextButton(onClick = { pendingRestoreUri = null }) { Text("Cancelar") } }
        )
    }

    if (restoredDone) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Cópia restaurada", fontSize = 16.sp) },
            text = { Text("Os dados foram restaurados. Toque em Fechar e abra o app outra vez.", fontSize = 13.sp) },
            confirmButton = { TextButton(onClick = { exitProcess(0) }) { Text("Fechar o app") } }
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Limpar dados de demonstração", fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Vão ser apagados todos os alunos, notas, presenças e notícias, e os professores sem conta. " +
                            "Escreva APAGAR para confirmar.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = clearConfirmText,
                        onValueChange = { clearConfirmText = it },
                        singleLine = true,
                        label = { Text("Escreva APAGAR") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = clearConfirmText.trim().uppercase(Locale.ROOT) == "APAGAR",
                    onClick = {
                        showClearDialog = false
                        onClearDemo { result ->
                            if (result == null) toast("Dados de demonstração apagados.") else toast(result)
                        }
                    }
                ) { Text("Apagar tudo", color = AcademicRed) }
            },
            dismissButton = { TextButton(onClick = { showClearDialog = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            content()
        }
    }
}
