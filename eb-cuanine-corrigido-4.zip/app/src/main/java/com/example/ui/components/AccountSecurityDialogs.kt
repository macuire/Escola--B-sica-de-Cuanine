package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AcademicRed

@Composable
private fun PinInput(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(6)) },
        label = { Text(label, fontSize = 12.sp) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}

/** Cada pessoa altera o seu próprio PIN, confirmando o actual. */
@Composable
fun ChangePinDialog(
    onSubmit: (current: String, newPin: String, confirm: String, onResult: (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var current by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Alterar o meu PIN", fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PinInput("PIN actual", current) { current = it; error = null }
                PinInput("Novo PIN (4 a 6 dígitos)", newPin) { newPin = it; error = null }
                PinInput("Repetir o novo PIN", confirm) { confirm = it; error = null }
                error?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSubmit(current, newPin, confirm) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

/** Mostra o código de recuperação uma única vez. */
@Composable
fun RecoveryCodeShownDialog(code: String, onDone: () -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Guarde o código de recuperação", fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = code,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp
                )
                Text(
                    "Escreva-o num papel ou tire uma captura de ecrã e guarde num sítio seguro. " +
                        "É a única forma de recuperar o acesso do Técnico ICT se esquecer o PIN. " +
                        "Não volta a ser mostrado.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = { TextButton(onClick = onDone) { Text("Já guardei o código") } }
    )
}

/** O Técnico ICT gera um código novo (o anterior deixa de funcionar), confirmando com o PIN. */
@Composable
fun RecoveryCodeDialog(
    onGenerate: (pin: String, onResult: (error: String?, code: String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var code by remember { mutableStateOf<String?>(null) }

    val shown = code
    if (shown != null) {
        RecoveryCodeShownDialog(code = shown, onDone = onDismiss)
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Código de recuperação", fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "Gera um código novo para recuperar o acesso se esquecer o PIN. O código anterior deixa de funcionar.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                PinInput("O meu PIN", pin) { pin = it; error = null }
                error?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onGenerate(pin) { result, generated ->
                    if (result == null && generated != null) code = generated else error = result
                }
            }) { Text("Gerar código") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
