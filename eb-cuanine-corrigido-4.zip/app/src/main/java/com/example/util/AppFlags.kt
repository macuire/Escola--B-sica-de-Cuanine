package com.example.util

import android.content.Context
import org.json.JSONObject

/** Pequenas definições guardadas no telemóvel: dados de demonstração, última cópia e códigos de recuperação. */
object AppFlags {
    private const val PREFS = "eb_cuanine_flags"
    private const val K_DEMO_CLEARED = "demo_cleared"
    private const val K_LAST_BACKUP = "last_backup"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isDemoCleared(context: Context): Boolean = prefs(context).getBoolean(K_DEMO_CLEARED, false)

    fun setDemoCleared(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(K_DEMO_CLEARED, value).apply()
    }

    fun lastBackup(context: Context): Long = prefs(context).getLong(K_LAST_BACKUP, 0L)

    fun setLastBackup(context: Context, time: Long) {
        prefs(context).edit().putLong(K_LAST_BACKUP, time).apply()
    }

    // Código de recuperação do Técnico ICT: só o resumo (hash) fica guardado
    fun saveRecovery(context: Context, accountId: Long, salt: String, hash: String) {
        prefs(context).edit()
            .putString("rec_salt_$accountId", salt)
            .putString("rec_hash_$accountId", hash)
            .apply()
    }

    fun recoverySalt(context: Context, accountId: Long): String? =
        prefs(context).getString("rec_salt_$accountId", null)

    fun recoveryHash(context: Context, accountId: Long): String? =
        prefs(context).getString("rec_hash_$accountId", null)

    /** Para a cópia de segurança (não inclui a data da última cópia). */
    fun exportJson(context: Context): String {
        val json = JSONObject()
        for ((key, value) in prefs(context).all) {
            if (key == K_LAST_BACKUP) continue
            when (value) {
                is Boolean -> json.put(key, value)
                is String -> json.put(key, value)
                is Long -> json.put(key, value)
                is Int -> json.put(key, value)
                else -> Unit
            }
        }
        return json.toString()
    }

    fun importJson(context: Context, raw: String) {
        val json = JSONObject(raw)
        val editor = prefs(context).edit()
        val last = prefs(context).getLong(K_LAST_BACKUP, 0L)
        editor.clear()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            when (val value = json.get(key)) {
                is Boolean -> editor.putBoolean(key, value)
                is String -> editor.putString(key, value)
                is Long -> editor.putLong(key, value)
                is Int -> editor.putLong(key, value.toLong())
                else -> Unit
            }
        }
        if (last != 0L) editor.putLong(K_LAST_BACKUP, last)
        editor.apply()
    }
}
