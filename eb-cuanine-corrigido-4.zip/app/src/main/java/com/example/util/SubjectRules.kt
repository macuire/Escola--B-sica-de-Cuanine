package com.example.util

/**
 * Decide se uma disciplina se lecciona numa classe.
 * O campo "applicableCycles" aceita ciclos ("1","2","3") e classes concretas ("g7","g11"...).
 */
object SubjectRules {
    fun appliesTo(applicableCycles: String, grade: Int, cycle: Int): Boolean {
        val tokens = applicableCycles.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        return tokens.contains(cycle.toString()) || tokens.contains("g$grade")
    }

    /** Lista de classes (1 a 12) em que a disciplina se lecciona. */
    fun gradesOf(applicableCycles: String): List<Int> =
        (1..12).filter { g -> appliesTo(applicableCycles, g, com.example.util.SneCalculator.getCycleForGrade(g)) }

    /** Texto curto, por exemplo "1.ª–6.ª, 8.ª". */
    fun describe(applicableCycles: String): String {
        val grades = gradesOf(applicableCycles)
        if (grades.isEmpty()) return "nenhuma classe"
        val parts = mutableListOf<String>()
        var start = grades.first()
        var prev = start
        for (g in grades.drop(1) + listOf(Int.MAX_VALUE)) {
            if (g != prev + 1) {
                parts.add(if (start == prev) "$start.ª" else "$start.ª–$prev.ª")
                start = g
            }
            prev = g
        }
        return parts.joinToString(", ")
    }

    fun tokensFor(grades: Set<Int>): String =
        grades.sorted().joinToString(",") { "g$it" }
}
