package com.example.util

import com.example.data.model.Classroom
import com.example.data.model.GradeRecord
import com.example.data.model.Student
import com.example.data.model.Subject

/** Monta as folhas de Excel de uma turma: uma folha por disciplina, para o trimestre escolhido. */
object PautaExcel {

    fun build(
        classroom: Classroom,
        term: Int,
        students: List<Student>,
        subjects: List<Subject>,
        grades: List<GradeRecord>
    ): List<XlsxSheet> {
        val classStudents = students
            .filter { it.gradeClass == classroom.grade && it.section == classroom.section }
            .sortedBy { it.fullName }
        val classSubjects = subjects
            .filter { SubjectRules.appliesTo(it.applicableCycles, classroom.grade, classroom.cycle) }
            .sortedBy { it.name }
        val byKey = grades.filter { it.term == term }.associateBy { it.studentId to it.subjectId }

        val usedNames = mutableSetOf<String>()
        val sheets = classSubjects.map { subject ->
            val rows = mutableListOf<List<Any?>>()
            rows.add(listOf("Escola Básica de Cuanine — Pauta de Notas"))
            rows.add(listOf("Turma: ${classroom.grade}.ª '${classroom.section}'", "Disciplina: ${subject.name}", "$term.º Trimestre"))
            rows.add(emptyList())
            rows.add(listOf("N.º", "N.º de processo", "Nome completo", "ACS 1", "ACS 2", "AT", "Exame", "Média trimestral", "Faltas"))
            classStudents.forEachIndexed { i, st ->
                val g = byKey[st.id to subject.id]
                rows.add(listOf(i + 1, st.studentNumber, st.fullName, g?.acs1, g?.acs2, g?.at, g?.exam, g?.termAverage, g?.absences))
            }
            XlsxSheet(
                name = uniqueSheetName(subject.name, usedNames),
                rows = rows,
                boldRows = setOf(0, 3),
                columnWidths = listOf(6, 18, 36, 8, 8, 8, 8, 16, 8)
            )
        }
        return sheets.ifEmpty {
            listOf(XlsxSheet("Pauta", listOf(listOf("Esta turma ainda não tem disciplinas.")), boldRows = setOf(0)))
        }
    }

    /** Nomes de folha do Excel: até 31 letras, sem []:*?/\ e sem repetições. */
    internal fun uniqueSheetName(raw: String, used: MutableSet<String>): String {
        val base = raw.replace(Regex("[\\[\\]:*?/\\\\]"), " ").trim().ifEmpty { "Folha" }.take(31)
        var name = base
        var n = 2
        while (!used.add(name.lowercase())) {
            val suffix = " ($n)"
            name = base.take(31 - suffix.length) + suffix
            n++
        }
        return name
    }
}
