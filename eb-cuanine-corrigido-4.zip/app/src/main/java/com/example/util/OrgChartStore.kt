package com.example.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class OrgPosition(
    val id: String,
    val title: String,
    val name: String
)

/** Guarda no telemóvel os cargos de topo do organograma, editáveis pelo ICT e pela Direcção. */
object OrgChartStore {
    private const val PREFS = "eb_cuanine_org"
    private const val KEY = "positions"

    fun defaults(): List<OrgPosition> = listOf(
        OrgPosition("directora", "Directora da Escola", ""),
        OrgPosition("pedagogico", "Director(a) Pedagógico(a)", ""),
        OrgPosition("secretaria", "Chefe da Secretaria", ""),
        OrgPosition("ict", "Técnico ICT & Dados", "")
    )

    fun load(context: Context): List<OrgPosition> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            val list = ArrayList<OrgPosition>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(OrgPosition(o.getString("id"), o.getString("title"), o.optString("name", "")))
            }
            list
        } catch (e: Exception) {
            defaults()
        }
    }

    fun exportJson(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)

    fun importJson(context: Context, raw: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, raw).apply()
    }

    fun save(context: Context, positions: List<OrgPosition>) {
        val arr = JSONArray()
        for (p in positions) {
            arr.put(JSONObject().put("id", p.id).put("title", p.title).put("name", p.name))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }
}
