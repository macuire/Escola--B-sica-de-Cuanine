package com.example.util

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class WrongPasswordException : IOException("Palavra-passe incorrecta ou ficheiro alterado.")

/**
 * Cifra as cópias de segurança com palavra-passe (AES-256-GCM, em blocos de 64 KB).
 * Sem a palavra-passe, quem roubar o ficheiro não consegue ler os dados.
 */
object BackupCrypto {
    private val MAGIC = "EBCBK001".toByteArray(Charsets.US_ASCII)
    private const val ITERATIONS = 120_000
    private const val BLOCK = 64 * 1024
    private const val IV_LENGTH = 12

    fun isEncryptedHeader(header: ByteArray, length: Int): Boolean =
        length >= MAGIC.size && header.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)

    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    fun encryptingStream(out: OutputStream, password: String): OutputStream {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        out.write(MAGIC)
        out.write(salt)
        return EncryptingOutput(out, deriveKey(password, salt))
    }

    fun decryptingStream(input: InputStream, password: String): InputStream {
        val magic = readFully(input, MAGIC.size)
        if (!magic.contentEquals(MAGIC)) throw IOException("Ficheiro inválido")
        val salt = readFully(input, 16)
        return DecryptingInput(input, deriveKey(password, salt))
    }

    private fun counterBytes(counter: Long): ByteArray = ByteBuffer.allocate(8).putLong(counter).array()

    private fun readFully(input: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n)
        var read = 0
        while (read < n) {
            val r = input.read(buf, read, n - read)
            if (r < 0) throw IOException("Ficheiro truncado")
            read += r
        }
        return buf
    }

    private class EncryptingOutput(
        private val out: OutputStream,
        private val key: SecretKeySpec
    ) : OutputStream() {
        private val buffer = ByteArray(BLOCK)
        private var count = 0
        private var counter = 0L
        private val random = SecureRandom()

        override fun write(b: Int) {
            buffer[count++] = b.toByte()
            if (count == BLOCK) flushBlock()
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            var o = off
            var l = len
            while (l > 0) {
                val n = minOf(l, BLOCK - count)
                System.arraycopy(b, o, buffer, count, n)
                count += n
                o += n
                l -= n
                if (count == BLOCK) flushBlock()
            }
        }

        private fun flushBlock() {
            if (count == 0) return
            val iv = ByteArray(IV_LENGTH)
            random.nextBytes(iv)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
            cipher.updateAAD(counterBytes(counter))
            val encrypted = cipher.doFinal(buffer, 0, count)
            counter++
            out.write(ByteBuffer.allocate(4).putInt(encrypted.size).array())
            out.write(iv)
            out.write(encrypted)
            count = 0
        }

        override fun flush() {
            out.flush()
        }

        override fun close() {
            flushBlock()
            out.write(ByteBuffer.allocate(4).putInt(0).array()) // marca de fim
            out.flush()
            out.close()
        }
    }

    private class DecryptingInput(
        private val input: InputStream,
        private val key: SecretKeySpec
    ) : InputStream() {
        private var block = ByteArray(0)
        private var pos = 0
        private var counter = 0L
        private var finished = false

        private fun fill(): Boolean {
            if (finished) return false
            val length = ByteBuffer.wrap(readFully(input, 4)).int
            if (length == 0) {
                finished = true
                return false
            }
            if (length < 16 || length > BLOCK + 16) throw IOException("Ficheiro inválido")
            val iv = readFully(input, IV_LENGTH)
            val encrypted = readFully(input, length)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            cipher.updateAAD(counterBytes(counter))
            block = try {
                cipher.doFinal(encrypted)
            } catch (e: GeneralSecurityException) {
                throw WrongPasswordException()
            }
            counter++
            pos = 0
            return true
        }

        override fun read(): Int {
            if (pos >= block.size && !fill()) return -1
            return block[pos++].toInt() and 0xff
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            if (pos >= block.size && !fill()) return -1
            val n = minOf(len, block.size - pos)
            System.arraycopy(block, pos, b, off, n)
            pos += n
            return n
        }

        override fun close() {
            input.close()
        }
    }
}
