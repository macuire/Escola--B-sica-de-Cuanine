package com.example.util

import android.content.Context
import com.example.data.database.AccountDatabase
import com.example.data.database.AppDatabase
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Cópia de segurança e restauro: um único ficheiro ZIP com as duas bases de dados
 * (escola e contas), o organograma, as definições e as fotografias dos alunos.
 */
object BackupManager {
    const val SCHOOL_DB = "eb_cuanine_school.db"
    const val ACCOUNT_DB = "eb_cuanine_accounts.db"
    private const val MANIFEST = "manifest.json"
    private const val ORG = "org_chart.json"
    private const val FLAGS = "flags.json"
    private const val PHOTOS = "photos/"

    class BackupException(message: String) : Exception(message)

    fun createBackup(context: Context, out: OutputStream, password: String? = null, markAsLast: Boolean = true) {
        val school = AppDatabase.getInstance(context)
        val accounts = AccountDatabase.getInstance(context)
        // Passa tudo o que está no registo temporário para o ficheiro principal
        school.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
        accounts.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
        val schoolVersion = school.openHelper.readableDatabase.version
        val accountVersion = accounts.openHelper.readableDatabase.version

        val target: OutputStream =
            if (password.isNullOrEmpty()) out else BackupCrypto.encryptingStream(out, password)
        ZipOutputStream(BufferedOutputStream(target)).use { zip ->
            putFile(zip, SCHOOL_DB, context.getDatabasePath(SCHOOL_DB))
            putFile(zip, ACCOUNT_DB, context.getDatabasePath(ACCOUNT_DB))
            OrgChartStore.exportJson(context)?.let { putText(zip, ORG, it) }
            putText(zip, FLAGS, AppFlags.exportJson(context))
            File(context.filesDir, "students").listFiles()?.forEach { f ->
                if (f.isFile) putFile(zip, PHOTOS + f.name, f)
            }
            putText(
                zip,
                MANIFEST,
                JSONObject()
                    .put("app", "EB Cuanine")
                    .put("schoolDbVersion", schoolVersion)
                    .put("accountDbVersion", accountVersion)
                    .put("createdAt", System.currentTimeMillis())
                    .toString()
            )
        }
        if (markAsLast) AppFlags.setLastBackup(context, System.currentTimeMillis())
    }

    /** Cópia automática guardada no próprio app (antes de importar, limpar ou restaurar). Mantém as 3 últimas. */
    fun autoBackup(context: Context) {
        val dir = File(context.filesDir, "auto-backups")
        dir.mkdirs()
        val file = File(dir, "auto-" + System.currentTimeMillis() + ".zip")
        FileOutputStream(file).use { createBackup(context, it, null, markAsLast = false) }
        dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(3)?.forEach { it.delete() }
    }

    /** Diz se o ficheiro escolhido é uma cópia protegida com palavra-passe. */
    fun isEncrypted(context: Context, uri: android.net.Uri): Boolean {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val head = ByteArray(8)
            val n = stream.read(head)
            return BackupCrypto.isEncryptedHeader(head, maxOf(n, 0))
        }
        return false
    }

    /**
     * Valida e restaura. Depois de terminar com sucesso o app tem de ser fechado e aberto outra vez.
     * Se a cópia for inválida ou de outra estrutura, lança BackupException e não mexe nos dados actuais.
     */
    fun restore(context: Context, input: InputStream, password: String? = null) {
        val staging = File(context.cacheDir, "restore_staging")
        staging.deleteRecursively()
        staging.mkdirs()

        val buffered = BufferedInputStream(input)
        buffered.mark(16)
        val head = ByteArray(8)
        val headRead = buffered.read(head)
        buffered.reset()
        val source: InputStream = if (BackupCrypto.isEncryptedHeader(head, maxOf(headRead, 0))) {
            if (password.isNullOrEmpty()) {
                staging.deleteRecursively()
                throw BackupException("Esta cópia está protegida. Escreva a palavra-passe.")
            }
            BackupCrypto.decryptingStream(buffered, password)
        } else {
            buffered
        }
        try {
            ZipInputStream(source).use { zin ->
                var entry: ZipEntry? = zin.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (!entry.isDirectory && isSafeName(name)) {
                        val target = File(staging, name)
                        target.parentFile?.mkdirs()
                        FileOutputStream(target).use { zin.copyTo(it) }
                    }
                    zin.closeEntry()
                    entry = zin.nextEntry
                }
            }
        } catch (e: WrongPasswordException) {
            staging.deleteRecursively()
            throw BackupException("Palavra-passe incorrecta ou ficheiro alterado.")
        } catch (e: java.io.IOException) {
            staging.deleteRecursively()
            throw BackupException("Não foi possível ler a cópia (ficheiro danificado).")
        }

        val schoolFile = File(staging, SCHOOL_DB)
        val accountFile = File(staging, ACCOUNT_DB)
        if (!schoolFile.exists() || !accountFile.exists()) {
            staging.deleteRecursively()
            throw BackupException("Este ficheiro não é uma cópia de segurança do EB Cuanine.")
        }

        val schoolVersion = AppDatabase.getInstance(context).openHelper.readableDatabase.version
        val accountVersion = AccountDatabase.getInstance(context).openHelper.readableDatabase.version
        if (sqliteUserVersion(schoolFile) != schoolVersion || sqliteUserVersion(accountFile) != accountVersion) {
            staging.deleteRecursively()
            throw BackupException(
                "Esta cópia foi feita por uma versão do app com outra estrutura de dados e não pode ser restaurada aqui."
            )
        }

        // Cópia automática dos dados actuais, por segurança
        runCatching { autoBackup(context) }

        // Daqui para a frente os dados actuais são substituídos
        AppDatabase.closeInstance()
        AccountDatabase.closeInstance()
        replaceDb(context, SCHOOL_DB, schoolFile)
        replaceDb(context, ACCOUNT_DB, accountFile)

        val photosDir = File(context.filesDir, "students")
        photosDir.deleteRecursively()
        photosDir.mkdirs()
        File(staging, "photos").listFiles()?.forEach { it.copyTo(File(photosDir, it.name), overwrite = true) }

        val org = File(staging, ORG)
        if (org.exists()) OrgChartStore.importJson(context, org.readText())
        val flags = File(staging, FLAGS)
        if (flags.exists()) AppFlags.importJson(context, flags.readText())

        staging.deleteRecursively()
    }

    private fun isSafeName(name: String): Boolean {
        if (name.contains("..") || name.startsWith("/") || name.contains("\\")) return false
        return name == SCHOOL_DB || name == ACCOUNT_DB || name == ORG || name == FLAGS || name == MANIFEST ||
            (name.startsWith(PHOTOS) && name.count { it == '/' } == 1)
    }

    private fun replaceDb(context: Context, name: String, source: File) {
        val target = context.getDatabasePath(name)
        File(target.path + "-wal").delete()
        File(target.path + "-shm").delete()
        File(target.path + "-journal").delete()
        target.delete()
        target.parentFile?.mkdirs()
        source.copyTo(target, overwrite = true)
    }

    /** Lê o campo "user_version" do cabeçalho do ficheiro SQLite (onde o Room guarda a versão). */
    internal fun sqliteUserVersion(file: File): Int {
        return try {
            RandomAccessFile(file, "r").use { raf ->
                val header = ByteArray(100)
                raf.readFully(header)
                val magic = String(header, 0, 15, Charsets.US_ASCII)
                if (magic != "SQLite format 3") {
                    -1
                } else {
                    ((header[60].toInt() and 0xff) shl 24) or
                        ((header[61].toInt() and 0xff) shl 16) or
                        ((header[62].toInt() and 0xff) shl 8) or
                        (header[63].toInt() and 0xff)
                }
            }
        } catch (e: Exception) {
            -1
        }
    }

    private fun putFile(zip: ZipOutputStream, name: String, file: File) {
        if (!file.exists()) return
        zip.putNextEntry(ZipEntry(name))
        FileInputStream(file).use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun putText(zip: ZipOutputStream, name: String, text: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(text.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }
}
