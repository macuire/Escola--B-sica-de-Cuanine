package com.example

import com.example.util.BackupCrypto
import com.example.util.SubjectRules
import com.example.util.WrongPasswordException
import com.example.util.XlsxSheet
import com.example.util.XlsxWriter
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Random
import java.util.zip.ZipInputStream

class XlsxAndCryptoTest {

    private fun encrypt(data: ByteArray, password: String): ByteArray {
        val bos = ByteArrayOutputStream()
        BackupCrypto.encryptingStream(bos, password).use { it.write(data) }
        return bos.toByteArray()
    }

    @Test
    fun cifraEDecifraComAPalavraPasseCerta() {
        val data = ByteArray(200_000).also { Random(7).nextBytes(it) }
        val encrypted = encrypt(data, "segredo123")
        assertFalse(encrypted.contentEquals(data))
        val decrypted = BackupCrypto.decryptingStream(ByteArrayInputStream(encrypted), "segredo123").readBytes()
        assertArrayEquals(data, decrypted)
    }

    @Test
    fun palavraPasseErradaFalha() {
        val encrypted = encrypt("dados da escola".toByteArray(), "segredo123")
        try {
            BackupCrypto.decryptingStream(ByteArrayInputStream(encrypted), "errada999").readBytes()
            fail("Devia falhar")
        } catch (e: WrongPasswordException) {
            // esperado
        }
    }

    @Test
    fun ficheiroAlteradoFalha() {
        val encrypted = encrypt(ByteArray(5000) { it.toByte() }, "segredo123")
        encrypted[encrypted.size / 2] = (encrypted[encrypted.size / 2].toInt() xor 0x55).toByte()
        try {
            BackupCrypto.decryptingStream(ByteArrayInputStream(encrypted), "segredo123").readBytes()
            fail("Devia falhar")
        } catch (e: java.io.IOException) {
            // esperado
        }
    }

    @Test
    fun xlsxTemAsPartesObrigatoriasEEscapaTexto() {
        val bos = ByteArrayOutputStream()
        XlsxWriter.write(
            bos,
            listOf(XlsxSheet("Notas", listOf(listOf("Ana & <Maria>", 12.5, null, 3)), boldRows = setOf(0)))
        )
        val entries = mutableMapOf<String, String>()
        ZipInputStream(ByteArrayInputStream(bos.toByteArray())).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                entries[e.name] = zin.readBytes().toString(Charsets.UTF_8)
                e = zin.nextEntry
            }
        }
        assertTrue(entries.containsKey("[Content_Types].xml"))
        assertTrue(entries.containsKey("xl/workbook.xml"))
        assertTrue(entries.containsKey("xl/worksheets/sheet1.xml"))
        val sheet = entries.getValue("xl/worksheets/sheet1.xml")
        assertTrue(sheet.contains("Ana &amp; &lt;Maria&gt;"))
        assertTrue(sheet.contains("<v>12.5</v>"))
    }

    @Test
    fun nomesDeColunaDoExcel() {
        assertEquals("A", XlsxWriter.colName(0))
        assertEquals("Z", XlsxWriter.colName(25))
        assertEquals("AA", XlsxWriter.colName(26))
    }

    @Test
    fun regrasDeDisciplinaPorCicloOuPorClasse() {
        assertTrue(SubjectRules.appliesTo("1,2,3", 2, 1))
        assertTrue(SubjectRules.appliesTo("3", 12, 3))
        assertFalse(SubjectRules.appliesTo("3", 2, 1))
        assertTrue(SubjectRules.appliesTo("g11,g12", 11, 3))
        assertFalse(SubjectRules.appliesTo("g11,g12", 10, 3))
        assertEquals("7.ª–9.ª, 11.ª", SubjectRules.describe("g7,g8,g9,g11"))
    }
}
