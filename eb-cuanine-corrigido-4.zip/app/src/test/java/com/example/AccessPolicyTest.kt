package com.example

import com.example.data.model.UserRole
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AccessPolicyTest {

    @Test
    fun estudanteEEncarregadoSoVeemAssuntosDeEstudantes() {
        val role = UserRole.ALUNO_ENCARREGADO
        assertTrue(AccessPolicy.canOpen(role, AppNavScreen.HOME)) // notícias, estatísticas, quadro de honra
        assertTrue(AccessPolicy.canOpen(role, AppNavScreen.PORTAL_ALUNO))
        assertTrue(AccessPolicy.canOpen(role, AppNavScreen.PROFESSORES))
        assertFalse(AccessPolicy.canOpen(role, AppNavScreen.PROFESSOR))
        assertFalse(AccessPolicy.canOpen(role, AppNavScreen.MATRICULA))
        assertFalse(AccessPolicy.canOpen(role, AppNavScreen.DIRECAO))
        assertFalse(AccessPolicy.canOpen(role, AppNavScreen.ICT_EDITOR))
        assertFalse(AccessPolicy.canOpen(role, AppNavScreen.CONTAS))
    }

    @Test
    fun professorTemTudoMenosDireccaoEIct() {
        val role = UserRole.PROFESSOR
        val blocked = setOf(AppNavScreen.DIRECAO, AppNavScreen.ICT_EDITOR, AppNavScreen.CONTAS, AppNavScreen.COPIAS, AppNavScreen.TURMAS)
        for (screen in AppNavScreen.values()) {
            assertTrue(
                "Professor: $screen",
                AccessPolicy.canOpen(role, screen) == (screen !in blocked)
            )
        }
    }

    @Test
    fun soOIctAbreAGestaoDeContas() {
        for (role in UserRole.values()) {
            val expected = role == UserRole.TECNICO_ICT
            assertTrue("Contas: $role", AccessPolicy.canOpen(role, AppNavScreen.CONTAS) == expected)
            assertTrue("ICT: $role", AccessPolicy.canOpen(role, AppNavScreen.ICT_EDITOR) == expected)
            assertTrue("Cópias: $role", AccessPolicy.canOpen(role, AppNavScreen.COPIAS) == expected)
        }
    }

    @Test
    fun todosOsPerfisVeemOInicioEAAbaProfessores() {
        for (role in UserRole.values()) {
            assertTrue(AccessPolicy.canOpen(role, AppNavScreen.HOME))
            assertTrue(AccessPolicy.canOpen(role, AppNavScreen.PROFESSORES))
        }
    }

    @Test
    fun direccaoEIctGeremTurmasEDisciplinas() {
        assertTrue(AccessPolicy.canOpen(UserRole.TECNICO_ICT, AppNavScreen.TURMAS))
        assertTrue(AccessPolicy.canOpen(UserRole.DIRECAO, AppNavScreen.TURMAS))
        assertFalse(AccessPolicy.canOpen(UserRole.PROFESSOR, AppNavScreen.TURMAS))
        assertFalse(AccessPolicy.canOpen(UserRole.ALUNO_ENCARREGADO, AppNavScreen.TURMAS))
    }
}
