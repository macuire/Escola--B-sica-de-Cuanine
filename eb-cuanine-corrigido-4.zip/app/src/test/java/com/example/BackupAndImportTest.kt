package com.example

import com.example.util.BackupManager
import com.example.util.SpreadsheetHelper
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File

class BackupAndImportTest {

    @Test
    fun leAVersaoDoCabecalhoSqlite() {
        val file = File.createTempFile("cabecalho", ".db")
        val header = ByteArray(100)
        "SQLite format 3".toByteArray(Charsets.US_ASCII).copyInto(header)
        header[63] = 7
        file.writeBytes(header)
        assertEquals(7, BackupManager.sqliteUserVersion(file))
        file.delete()
    }

    @Test
    fun ficheiroQueNaoESqliteDevolveMenosUm() {
        val file = File.createTempFile("falso", ".db")
        file.writeText("isto não é uma base de dados")
        assertEquals(-1, BackupManager.sqliteUserVersion(file))
        file.delete()
    }

    @Test
    fun normalizaDatasDeNascimento() {
        assertEquals("2016-04-12", SpreadsheetHelper.normalizeBirthDate("12/04/2016"))
        assertEquals("2016-04-05", SpreadsheetHelper.normalizeBirthDate("2016-4-5"))
        assertEquals("2016-04-12", SpreadsheetHelper.normalizeBirthDate("2016-04-12"))
    }

    @Test
    fun datasInvalidasUsamAOValorPorOmissao() {
        assertEquals("2015-01-01", SpreadsheetHelper.normalizeBirthDate("data errada"))
        assertEquals("2015-01-01", SpreadsheetHelper.normalizeBirthDate("31/13/2016"))
    }

    @Test
    fun numeroDeSerieDoExcelViraData() {
        // 42472 = 12 de Abril de 2016 no Excel
        assertEquals("2016-04-12", SpreadsheetHelper.normalizeBirthDate("42472"))
    }
}
