package com.example.data.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.data.model.UserAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM user_accounts ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<UserAccount>>

    @Query("SELECT * FROM user_accounts WHERE phone = :phone LIMIT 1")
    suspend fun findByPhone(phone: String): UserAccount?

    @Query("SELECT COUNT(*) FROM user_accounts WHERE role = :role AND status = 'ACTIVO'")
    suspend fun countActiveByRole(role: String): Int

    @Query("SELECT COUNT(*) FROM user_accounts WHERE role = :role AND status = 'ACTIVO'")
    fun observeActiveCountByRole(role: String): Flow<Int>

    @Insert
    suspend fun insert(account: UserAccount): Long

    @Update
    suspend fun update(account: UserAccount)

    @Delete
    suspend fun delete(account: UserAccount)
}

/**
 * Base de dados separada para as contas de acesso (cadastros). É uma base nova,
 * por isso não mexe nem apaga os dados escolares já existentes.
 */
@Database(entities = [UserAccount::class], version = 1, exportSchema = false)
abstract class AccountDatabase : RoomDatabase() {
    abstract fun accountDao(): AccountDao

    companion object {
        @Volatile
        private var INSTANCE: AccountDatabase? = null

        fun getInstance(context: Context): AccountDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AccountDatabase::class.java,
                    "eb_cuanine_accounts.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
