package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Conta de acesso ao app. Criada por cadastro (fica PENDENTE) e gerida pelo Técnico ICT.
 * O PIN nunca é guardado em texto: apenas um resumo (hash) com sal aleatório.
 */
@Entity(
    tableName = "user_accounts",
    indices = [Index(value = ["phone"], unique = true)]
)
data class UserAccount(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fullName: String,
    val phone: String, // só dígitos, 9 algarismos (identificador de acesso)
    val accountType: String, // "ESTUDANTE", "ENCARREGADO", "DOCENTE", "NAO_DOCENTE"
    val role: String, // nome de um UserRole, atribuído/alterado pelo ICT
    val status: String, // "PENDENTE", "ACTIVO", "BLOQUEADO"
    val linkedStudentNumber: String? = null, // aluno associado (estudantes e encarregados)
    val jobTitle: String = "", // função/cargo (funcionários)
    val pinSalt: String,
    val pinHash: String,
    val failedAttempts: Int = 0,
    val lockedUntil: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isFamilyAccount: Boolean
        get() = accountType == "ESTUDANTE" || accountType == "ENCARREGADO"
}
