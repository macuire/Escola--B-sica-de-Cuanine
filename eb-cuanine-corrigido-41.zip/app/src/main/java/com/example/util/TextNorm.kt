package com.example.util

import java.text.Normalizer
import java.util.Locale

object TextNorm {
    /** Minúsculas, sem acentos nem pontuação, para comparar nomes escritos de formas diferentes. */
    fun normalize(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** "Matematica" == "Matemática"; "História" encaixa em "Ciências Sociais / História". */
    fun sameSubject(a: String, b: String): Boolean {
        val x = normalize(a)
        val y = normalize(b)
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        return x.length >= 4 && y.length >= 4 && (x.contains(y) || y.contains(x))
    }
}
