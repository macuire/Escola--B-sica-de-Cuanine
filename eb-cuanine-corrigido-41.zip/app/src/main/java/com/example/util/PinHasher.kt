package com.example.util

import java.security.MessageDigest
import java.security.SecureRandom

/** Resumo (hash) do PIN com sal aleatório e várias repetições. O PIN em si nunca é guardado. */
object PinHasher {
    private const val ITERATIONS = 20000

    fun newSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return toHex(bytes)
    }

    fun hash(pin: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var data = (salt + ":" + pin).toByteArray(Charsets.UTF_8)
        repeat(ITERATIONS) { data = md.digest(data) }
        return toHex(data)
    }

    fun verify(pin: String, salt: String, expectedHash: String): Boolean {
        val actual = hash(pin, salt).toByteArray(Charsets.UTF_8)
        return MessageDigest.isEqual(actual, expectedHash.toByteArray(Charsets.UTF_8))
    }

    private fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xff
            sb.append("0123456789abcdef"[v shr 4])
            sb.append("0123456789abcdef"[v and 0x0f])
        }
        return sb.toString()
    }
}
