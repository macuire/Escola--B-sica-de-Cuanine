package com.example

import com.example.data.model.UserRole

/** Que áreas do app cada perfil pode abrir. A lista também define a ordem na gaveta de navegação. */
object AccessPolicy {

    fun allowed(role: UserRole): List<AppNavScreen> = when (role) {
        // Estudantes e encarregados: só assuntos de estudantes + notícias, estatísticas e quadro de honra (Início)
        UserRole.ALUNO_ENCARREGADO -> listOf(
            AppNavScreen.HOME,
            AppNavScreen.PORTAL_ALUNO,
            AppNavScreen.PROFESSORES
        )
        // Professores: tudo, menos a área da Direcção e a área do ICT
        UserRole.PROFESSOR -> listOf(
            AppNavScreen.HOME,
            AppNavScreen.PROFESSORES,
            AppNavScreen.ORGANOGRAMA,
            AppNavScreen.PROFESSOR,
            AppNavScreen.MATRICULA,
            AppNavScreen.PORTAL_ALUNO,
            AppNavScreen.CONSELHO
        )
        UserRole.SECRETARIA -> listOf(
            AppNavScreen.HOME,
            AppNavScreen.PROFESSORES,
            AppNavScreen.ORGANOGRAMA,
            AppNavScreen.MATRICULA,
            AppNavScreen.PORTAL_ALUNO
        )
        UserRole.CONSELHO_ESCOLA -> listOf(
            AppNavScreen.HOME,
            AppNavScreen.PROFESSORES,
            AppNavScreen.CONSELHO,
            AppNavScreen.DIRECAO
        )
        UserRole.DIRECAO -> listOf(
            AppNavScreen.HOME,
            AppNavScreen.PROFESSORES,
            AppNavScreen.ORGANOGRAMA,
            AppNavScreen.DIRECAO,
            AppNavScreen.PROFESSOR,
            AppNavScreen.MATRICULA,
            AppNavScreen.PORTAL_ALUNO,
            AppNavScreen.CONSELHO
        )
        UserRole.TECNICO_ICT -> AppNavScreen.values().toList()
    }

    fun canOpen(role: UserRole, screen: AppNavScreen): Boolean = screen in allowed(role)
}
