package com.example.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EnrollmentStatus
import com.example.data.model.GradeRecord
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.data.model.UserRole
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.DocxExporter
import com.example.util.PdfExporter
import com.example.util.PrintHelper
import com.example.util.SneCalculator
import java.io.File
import java.util.Locale

@Composable
fun StudentProfileDialog(
    student: Student,
    subjects: List<Subject>,
    grades: List<GradeRecord>,
    currentRole: UserRole,
    onUpdateStatus: (studentId: Long, newStatus: String, dest: String?, reason: String?) -> Unit,
    onDismiss: () -> Unit,
    onEdit: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var isEditingStatus by remember { mutableStateOf(false) }
    var selectedStatus by remember { mutableStateOf(student.enrollmentStatus) }
    var transferDest by remember { mutableStateOf(student.transferDestination ?: "") }
    var dropReason by remember { mutableStateOf(student.dropReason ?: "") }

    val studentGrades = remember(grades, student.id) {
        grades.filter { it.studentId == student.id }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Ficha Completa do Aluno",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = CuanineNavy
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Fechar")
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Cartão com Foto, Nome e Status
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            val localBmp = remember(student.photoUri) {
                                if (student.photoUri != null && File(student.photoUri).exists()) {
                                    BitmapFactory.decodeFile(student.photoUri)
                                } else null
                            }

                            if (localBmp != null) {
                                Image(
                                    bitmap = localBmp.asImageBitmap(),
                                    contentDescription = student.fullName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .border(2.dp, GoldAccent, CircleShape)
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .background(GoldAccent),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = student.fullName.take(1),
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CuanineNavy
                                    )
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = student.fullName,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "N.º ${student.studentNumber} • ${student.gradeClass}.ª Classe '${student.section}'",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))

                                // Status Badge
                                val statusEnum = when (student.enrollmentStatus) {
                                    "DESISTIDO" -> EnrollmentStatus.DESISTIDO
                                    "TRANSFERIDO" -> EnrollmentStatus.TRANSFERIDO
                                    else -> EnrollmentStatus.ACTIVO
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(statusEnum.badgeColorHex))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = statusEnum.label.uppercase(Locale.getDefault()),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                // Gestor de Estado de Matrícula (Direcção e Técnico ICT)
                if (currentRole == UserRole.DIRECAO || currentRole == UserRole.TECNICO_ICT) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Gestão de Ciclo de Matrícula:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    TextButton(onClick = { isEditingStatus = !isEditingStatus }) {
                                        Text(if (isEditingStatus) "Fechar" else "Alterar Estado", fontSize = 11.sp)
                                    }
                                }

                                if (isEditingStatus) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        listOf("ACTIVO", "TRANSFERIDO", "DESISTIDO").forEach { st ->
                                            FilterChip(
                                                selected = selectedStatus == st,
                                                onClick = { selectedStatus = st },
                                                label = { Text(st, fontSize = 10.sp) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }

                                    if (selectedStatus == "TRANSFERIDO") {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        OutlinedTextField(
                                            value = transferDest,
                                            onValueChange = { transferDest = it },
                                            label = { Text("Escola de Destino", fontSize = 11.sp) },
                                            placeholder = { Text("ex: EPC Manhiça-Sede") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    if (selectedStatus == "DESISTIDO") {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        OutlinedTextField(
                                            value = dropReason,
                                            onValueChange = { dropReason = it },
                                            label = { Text("Motivo da Desistência", fontSize = 11.sp) },
                                            placeholder = { Text("ex: Mudança de residência / Actividade agrícola") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = {
                                            onUpdateStatus(
                                                student.id,
                                                selectedStatus,
                                                if (selectedStatus == "TRANSFERIDO") transferDest else null,
                                                if (selectedStatus == "DESISTIDO") dropReason else null
                                            )
                                            isEditingStatus = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy),
                                        modifier = Modifier.align(Alignment.End)
                                    ) {
                                        Text("Gravar Estado", fontSize = 11.sp)
                                    }
                                } else {
                                    if (student.enrollmentStatus == "TRANSFERIDO") {
                                        Text(
                                            text = "Destino: ${student.transferDestination ?: "Não especificado"}",
                                            fontSize = 11.sp,
                                            color = GoldAccent
                                        )
                                    } else if (student.enrollmentStatus == "DESISTIDO") {
                                        Text(
                                            text = "Motivo: ${student.dropReason ?: "Não especificado"}",
                                            fontSize = 11.sp,
                                            color = AcademicRed
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Dados Pessoais e Familiares
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(10.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Dados Pessoais e de Identificação", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CuanineNavy)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("• Documento: ${student.docType} n.º ${student.docNumber.ifBlank { "N/D" }}", fontSize = 11.sp)
                            Text("• Data de Nascimento: ${student.birthDate} (Género: ${if (student.gender == "M") "Masculino" else "Feminino"})", fontSize = 11.sp)
                            Text("• Encarregado de Educação: ${student.guardianName}", fontSize = 11.sp)
                            Text("• Contacto Telefónico: ${student.guardianPhone}", fontSize = 11.sp)
                            Text("• Residência: ${student.address}", fontSize = 11.sp)
                            Text("• Ciclo Curricular: ${SneCalculator.getCycleTitle(student.cycle)}", fontSize = 11.sp)
                        }
                    }
                }

                // Histórico de Rendimento Escolar
                item {
                    Text(
                        text = "Histórico Académico e Notas (SNE 2026):",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                items(subjects.size) { idx ->
                    val sub = subjects[idx]
                    val g1 = studentGrades.find { it.subjectId == sub.id && it.term == 1 }
                    val g2 = studentGrades.find { it.subjectId == sub.id && it.term == 2 }
                    val g3 = studentGrades.find { it.subjectId == sub.id && it.term == 3 }
                    val valid = listOfNotNull(g1?.termAverage, g2?.termAverage, g3?.termAverage)
                    val avgStr = if (valid.isNotEmpty()) String.format(Locale.US, "%.1f", valid.average()) else "-"

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(8.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(sub.name, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.5f))
                            Text("T1: ${g1?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"}", fontSize = 10.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("T2: ${g2?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"}", fontSize = 10.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("T3: ${g3?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"}", fontSize = 10.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Média: $avgStr", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CuanineNavy)
                        }
                    }
                }

                // Botões de Impressão Direta e Exportação Oficial MINEDH
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Emissão e Impressão Oficial MINEDH:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Impressão Direta (Wi-Fi / Bluetooth PrintManager)
                        Button(
                            onClick = {
                                val pdfFile = PdfExporter.exportBoletimPdf(context, student, subjects, studentGrades)
                                PrintHelper.printPdfDocument(context, pdfFile, "Boletim_${student.studentNumber}")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AcademicEmerald),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Imprimir Directo", fontSize = 11.sp)
                        }

                        // Emitir Declaração
                        Button(
                            onClick = {
                                val cert = PdfExporter.exportCertificadoMatriculaPdf(context, student)
                                PrintHelper.printPdfDocument(context, cert, "Declaracao_${student.studentNumber}")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Declaração", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    ExportActionBar(
                        onExportPdf = {
                            val file = PdfExporter.exportBoletimPdf(context, student, subjects, studentGrades)
                            PdfExporter.shareFile(context, file)
                        },
                        onExportDocx = {
                            val file = DocxExporter.exportBoletimDocx(context, student, subjects, studentGrades)
                            DocxExporter.shareDocx(context, file)
                        },
                        pdfLabel = "Boletim (.pdf)",
                        docxLabel = "Boletim (.docx)"
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Fechar")
            }
        },
        dismissButton = {
            if (onEdit != null) {
                TextButton(onClick = onEdit) { Text("Editar dados") }
            }
        }
    )
}
