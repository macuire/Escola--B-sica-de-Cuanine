package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.GoldAccent

private sealed class AdminDialog {
    abstract val account: UserAccount
    data class Approve(override val account: UserAccount) : AdminDialog()
    data class ChangeRole(override val account: UserAccount) : AdminDialog()
    data class ResetPin(override val account: UserAccount) : AdminDialog()
    data class Delete(override val account: UserAccount) : AdminDialog()
}

private fun typeLabel(type: String): String = when (type) {
    "ESTUDANTE" -> "Estudante"
    "ENCARREGADO" -> "Encarregado"
    "DOCENTE" -> "Docente"
    else -> "Não docente"
}

private fun statusLabel(status: String): String = when (status) {
    "PENDENTE" -> "Pendente"
    "ACTIVO" -> "Activo"
    else -> "Bloqueado"
}

private fun statusColor(status: String): Color = when (status) {
    "PENDENTE" -> GoldAccent
    "ACTIVO" -> AcademicGreen
    else -> AcademicRed
}

private fun roleOf(account: UserAccount): UserRole =
    runCatching { UserRole.valueOf(account.role) }.getOrDefault(UserRole.ALUNO_ENCARREGADO)

/** Gestão dos cadastros pelo Técnico ICT: aprovar, bloquear, mudar função, repor PIN e eliminar. */
@Composable
fun AccountsAdminScreen(
    accounts: List<UserAccount>,
    currentAccountId: Long?,
    onApprove: (UserAccount, UserRole) -> Unit,
    onSetStatus: (UserAccount, String) -> Unit,
    onChangeRole: (UserAccount, UserRole) -> Unit,
    onResetPin: (UserAccount, String, (String?) -> Unit) -> Unit,
    onDelete: (UserAccount) -> Unit,
    modifier: Modifier = Modifier
) {
    var filter by remember { mutableStateOf("PENDENTE") } // PENDENTE, ACTIVO, BLOQUEADO, TODOS
    var dialog by remember { mutableStateOf<AdminDialog?>(null) }

    val pendingCount = accounts.count { it.status == "PENDENTE" }
    val shown = if (filter == "TODOS") accounts else accounts.filter { it.status == filter }

    Column(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(
                text = "Contas e Cadastros",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${accounts.size} contas • $pendingCount a aguardar aprovação",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                FilterChip(selected = filter == "PENDENTE", onClick = { filter = "PENDENTE" }, label = { Text("Pendentes") })
                FilterChip(selected = filter == "ACTIVO", onClick = { filter = "ACTIVO" }, label = { Text("Activas") })
                FilterChip(selected = filter == "BLOQUEADO", onClick = { filter = "BLOQUEADO" }, label = { Text("Bloqueadas") })
                FilterChip(selected = filter == "TODOS", onClick = { filter = "TODOS" }, label = { Text("Todas") })
            }
        }

        if (shown.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.TopCenter) {
                Text(
                    text = "Sem contas nesta lista.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(shown, key = { it.id }) { account ->
                    AccountCard(
                        account = account,
                        isSelf = account.id == currentAccountId,
                        onApprove = {
                            if (account.isFamilyAccount) onApprove(account, UserRole.ALUNO_ENCARREGADO)
                            else dialog = AdminDialog.Approve(account)
                        },
                        onBlock = { onSetStatus(account, "BLOQUEADO") },
                        onReactivate = { onSetStatus(account, "ACTIVO") },
                        onChangeRole = { dialog = AdminDialog.ChangeRole(account) },
                        onResetPin = { dialog = AdminDialog.ResetPin(account) },
                        onDelete = { dialog = AdminDialog.Delete(account) }
                    )
                }
            }
        }
    }

    when (val d = dialog) {
        null -> Unit
        is AdminDialog.Approve -> RoleDialog(
            title = "Aprovar ${d.account.fullName}",
            initial = roleOf(d.account),
            confirmLabel = "Aprovar",
            onConfirm = { role -> onApprove(d.account, role); dialog = null },
            onDismiss = { dialog = null }
        )
        is AdminDialog.ChangeRole -> RoleDialog(
            title = "Função de ${d.account.fullName}",
            initial = roleOf(d.account),
            confirmLabel = "Guardar",
            onConfirm = { role -> onChangeRole(d.account, role); dialog = null },
            onDismiss = { dialog = null }
        )
        is AdminDialog.ResetPin -> ResetPinDialog(
            name = d.account.fullName,
            onConfirm = { newPin, report -> onResetPin(d.account, newPin, report) },
            onDone = { dialog = null },
            onDismiss = { dialog = null }
        )
        is AdminDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Eliminar conta") },
            text = { Text("Eliminar a conta de ${d.account.fullName}? Esta acção não pode ser desfeita.") },
            confirmButton = {
                TextButton(onClick = { onDelete(d.account); dialog = null }) {
                    Text("Eliminar", color = AcademicRed)
                }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun AccountCard(
    account: UserAccount,
    isSelf: Boolean,
    onApprove: () -> Unit,
    onBlock: () -> Unit,
    onReactivate: () -> Unit,
    onChangeRole: () -> Unit,
    onResetPin: () -> Unit,
    onDelete: () -> Unit
) {
    val color = statusColor(account.status)
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = account.fullName + if (isSelf) " (você)" else "",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = typeLabel(account.accountType) + " • " + roleOf(account).label,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(color.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = statusLabel(account.status),
                        color = color,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Contacto: ${account.phone}", fontSize = 12.sp)
            if (account.isFamilyAccount && account.linkedStudentNumber != null) {
                Text(text = "Aluno: ${account.linkedStudentNumber}", fontSize = 12.sp)
            }
            if (account.jobTitle.isNotBlank()) {
                Text(text = "Função: ${account.jobTitle}", fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                if (account.status == "PENDENTE") {
                    OutlinedButton(onClick = onApprove) { Text("Aprovar", fontSize = 12.sp) }
                }
                if (account.status == "ACTIVO" && !isSelf) {
                    OutlinedButton(onClick = onBlock) { Text("Bloquear", fontSize = 12.sp) }
                }
                if (account.status == "BLOQUEADO") {
                    OutlinedButton(onClick = onReactivate) { Text("Reactivar", fontSize = 12.sp) }
                }
                if (!account.isFamilyAccount && !isSelf && account.status != "PENDENTE") {
                    OutlinedButton(onClick = onChangeRole) { Text("Função", fontSize = 12.sp) }
                }
                OutlinedButton(onClick = onResetPin) { Text("Repor PIN", fontSize = 12.sp) }
                if (!isSelf) {
                    OutlinedButton(onClick = onDelete) {
                        Text(
                            if (account.status == "PENDENTE") "Rejeitar" else "Eliminar",
                            fontSize = 12.sp,
                            color = AcademicRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RoleDialog(
    title: String,
    initial: UserRole,
    confirmLabel: String,
    onConfirm: (UserRole) -> Unit,
    onDismiss: () -> Unit
) {
    val options = UserRole.values().filter { it != UserRole.ALUNO_ENCARREGADO }
    var selected by remember { mutableStateOf(if (initial in options) initial else UserRole.PROFESSOR) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontSize = 16.sp) },
        text = {
            Column {
                options.forEach { role ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        RadioButton(selected = selected == role, onClick = { selected = role })
                        Text(role.label, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(selected) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ResetPinDialog(
    name: String,
    onConfirm: (String, (String?) -> Unit) -> Unit,
    onDone: () -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Repor PIN de $name", fontSize = 16.sp) },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); error = null },
                    label = { Text("Novo PIN (4 a 6 dígitos)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(it, color = AcademicRed, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm(pin) { result ->
                    if (result == null) onDone() else error = result
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
