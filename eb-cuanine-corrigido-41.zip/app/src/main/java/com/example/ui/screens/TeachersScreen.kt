package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Classroom
import com.example.data.model.Subject
import com.example.data.model.Teacher
import com.example.ui.components.EditField
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.TextNorm

private fun initialsOf(name: String): String =
    name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }

/**
 * Aba "Professores": lista do corpo docente e, para o professor com sessão iniciada,
 * o painel pessoal (lançar notas, publicar informação, agendar avaliação, perfil).
 */
@Composable
fun TeachersScreen(
    teachers: List<Teacher>,
    showContacts: Boolean,
    modifier: Modifier = Modifier,
    canEdit: Boolean = false,
    onSave: (Teacher, (String?) -> Unit) -> Unit = { _, _ -> },
    subjects: List<Subject> = emptyList(),
    classrooms: List<Classroom> = emptyList(),
    myTeacher: Teacher? = null,
    onOpenGrades: () -> Unit = {},
    onPublishNotice: (String, String, String, (String?) -> Unit) -> Unit = { _, _, _, _ -> },
    onUpdateMyProfile: (String, String, (String?) -> Unit) -> Unit = { _, _, _ -> }
) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Teacher?>(null) }
    var editing by remember { mutableStateOf<Teacher?>(null) }

    val shown = teachers
        .filter { canEdit || it.status == "ACTIVO" }
        .filter {
            query.isBlank() ||
                it.fullName.contains(query.trim(), ignoreCase = true) ||
                it.mainSubjects.contains(query.trim(), ignoreCase = true)
        }
        .sortedBy { it.fullName }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column {
                Text(text = "Professores", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = "${shown.size} docentes",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (myTeacher != null) {
            item {
                TeacherPanel(
                    teacher = myTeacher,
                    subjects = subjects,
                    classrooms = classrooms,
                    onOpenGrades = onOpenGrades,
                    onPublishNotice = onPublishNotice,
                    onUpdateMyProfile = onUpdateMyProfile
                )
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Pesquisar por nome ou disciplina", fontSize = 12.sp) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (shown.isEmpty()) {
            item {
                Text(
                    text = "Nenhum professor encontrado.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
            }
        } else {
            items(shown, key = { it.id }) { teacher ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selected = teacher }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(CuanineNavy),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = initialsOf(teacher.fullName),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = teacher.fullName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = teacher.mainSubjects,
                                fontSize = 12.sp,
                                color = AcademicEmerald,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = teacher.category + " • " + teacher.assignedClassroom,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }

    selected?.let { teacher ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(teacher.fullName, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Categoria: ${teacher.category}", fontSize = 13.sp)
                    Text("Disciplinas: ${teacher.mainSubjects}", fontSize = 13.sp)
                    Text("Sala: ${teacher.assignedClassroom}", fontSize = 13.sp)
                    if (showContacts) {
                        Text("Contacto: ${teacher.phone}", fontSize = 13.sp)
                        teacher.email?.let { Text("Email: $it", fontSize = 13.sp) }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(teacher.bio, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("Fechar") } },
            dismissButton = {
                if (canEdit) {
                    TextButton(onClick = { editing = teacher; selected = null }) { Text("Editar") }
                }
            }
        )
    }

    editing?.let { teacher ->
        EditTeacherDialog(
            teacher = teacher,
            availableSubjects = subjects.map { it.name },
            onSave = onSave,
            onDismiss = { editing = null }
        )
    }
}

// ----------------------------- Painel do professor -----------------------------

@Composable
private fun TeacherPanel(
    teacher: Teacher,
    subjects: List<Subject>,
    classrooms: List<Classroom>,
    onOpenGrades: () -> Unit,
    onPublishNotice: (String, String, String, (String?) -> Unit) -> Unit,
    onUpdateMyProfile: (String, String, (String?) -> Unit) -> Unit
) {
    var dialog by remember { mutableStateOf("") } // "", "INFO", "AVALIACAO", "PERFIL"

    val mySubjects = remember(teacher.mainSubjects, subjects) {
        val names = teacher.mainSubjects.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        subjects.filter { sj -> names.any { n -> TextNorm.sameSubject(n, sj.name) } }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CuanineNavy),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("O meu painel", color = GoldAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(teacher.fullName, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
                text = if (mySubjects.isEmpty()) {
                    "Ainda sem disciplinas atribuídas. Peça ao ICT ou à Direcção para as definir."
                } else {
                    "Disciplinas: " + mySubjects.joinToString(", ") { it.name }
                },
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 12.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                PanelButton("Lançar notas", GoldAccent, onOpenGrades)
                PanelButton("Publicar informação", AcademicEmerald) { dialog = "INFO" }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                PanelButton("Agendar avaliação", AcademicBlue) { dialog = "AVALIACAO" }
                PanelButton("O meu perfil", Color.White.copy(alpha = 0.18f)) { dialog = "PERFIL" }
            }
        }
    }

    when (dialog) {
        "INFO" -> PublishInfoDialog(onPublish = onPublishNotice, onDismiss = { dialog = "" })
        "AVALIACAO" -> ScheduleAssessmentDialog(
            subjectOptions = if (mySubjects.isEmpty()) subjects.map { it.name } else mySubjects.map { it.name },
            classOptions = classrooms,
            onPublish = onPublishNotice,
            onDismiss = { dialog = "" }
        )
        "PERFIL" -> MyProfileDialog(teacher = teacher, onSave = onUpdateMyProfile, onDismiss = { dialog = "" })
        else -> Unit
    }
}

@Composable
private fun RowScope.PanelButton(text: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        modifier = Modifier.weight(1f)
    ) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun PublishInfoDialog(
    onPublish: (String, String, String, (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Comunidade") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Publicar informação", fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    "Aparece no Mural de Notícias e Comunicados, visível a todos.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                EditField("Título", title) { title = it; error = null }
                EditField("Texto", body, singleLine = false) { body = it; error = null }
                ChipRow(listOf("Comunidade", "Desporto e Ciência", "Saúde Escolar"), category) { category = it }
                error?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onPublish(title, body, category) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("Publicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ScheduleAssessmentDialog(
    subjectOptions: List<String>,
    classOptions: List<Classroom>,
    onPublish: (String, String, String, (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    val classLabels = classOptions.map { "${it.grade}.ª '${it.section}'" }
    var subject by remember { mutableStateOf(subjectOptions.firstOrNull() ?: "") }
    var classKey by remember { mutableStateOf(classLabels.firstOrNull() ?: "") }
    var type by remember { mutableStateOf("Teste") }
    var date by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Agendar avaliação", fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Disciplina", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                ChipRow(subjectOptions, subject) { subject = it; error = null }
                Text("Turma", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                ChipRow(classLabels, classKey) { classKey = it; error = null }
                Text("Tipo", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                ChipRow(listOf("Teste", "Trabalho", "Exame", "Prova oral"), type) { type = it }
                EditField("Data (AAAA-MM-DD)", date, KeyboardType.Number) { date = it; error = null }
                EditField("Observações (opcional)", note, singleLine = false) { note = it }
                error?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parts = date.trim().split("-")
                val validDate = Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(date.trim()) &&
                    (parts[1].toIntOrNull() ?: 0) in 1..12 &&
                    (parts[2].toIntOrNull() ?: 0) in 1..31
                if (subject.isBlank() || classKey.isBlank()) {
                    error = "Escolha a disciplina e a turma."
                } else if (!validDate) {
                    error = "Data no formato AAAA-MM-DD (ex.: 2026-11-20)."
                } else {
                    val shownDate = parts[2] + "/" + parts[1] + "/" + parts[0]
                    val extra = if (note.isBlank()) "" else " " + note.trim()
                    onPublish(
                        "$type de $subject — $classKey",
                        "Disciplina: $subject. Turma: $classKey. Data: $shownDate.$extra",
                        "Avaliações"
                    ) { result ->
                        if (result == null) onDismiss() else error = result
                    }
                }
            }) { Text("Agendar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun MyProfileDialog(
    teacher: Teacher,
    onSave: (String, String, (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var bio by remember(teacher.id) { mutableStateOf(teacher.bio) }
    var email by remember(teacher.id) { mutableStateOf(teacher.email ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("O meu perfil", fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    "O nome, o contacto e as disciplinas são alterados pelo ICT ou pela Direcção.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                EditField("Apresentação / biografia", bio, singleLine = false) { bio = it; error = null }
                EditField("Email (opcional)", email, KeyboardType.Email) { email = it; error = null }
                error?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(bio, email) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ----------------------------- Edição pelo ICT / Direcção / Secretaria -----------------------------

@Composable
private fun EditTeacherDialog(
    teacher: Teacher,
    availableSubjects: List<String>,
    onSave: (Teacher, (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var fullName by remember(teacher.id) { mutableStateOf(teacher.fullName) }
    var phone by remember(teacher.id) { mutableStateOf(teacher.phone) }
    var email by remember(teacher.id) { mutableStateOf(teacher.email ?: "") }
    var subjects by remember(teacher.id) { mutableStateOf(teacher.mainSubjects) }
    var classroom by remember(teacher.id) { mutableStateOf(teacher.assignedClassroom) }
    var category by remember(teacher.id) { mutableStateOf(teacher.category) }
    var contract by remember(teacher.id) { mutableStateOf(teacher.contractType) }
    var status by remember(teacher.id) { mutableStateOf(teacher.status) }
    var bio by remember(teacher.id) { mutableStateOf(teacher.bio) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar professor", fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = teacher.teacherCode,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                EditField("Nome completo", fullName) { fullName = it; error = null }
                EditField("Contacto", phone, KeyboardType.Phone) { phone = it; error = null }
                EditField("Email (opcional)", email, KeyboardType.Email) { email = it; error = null }
                EditField("Disciplinas", subjects) { subjects = it; error = null }
                if (availableSubjects.isNotEmpty()) {
                    Text(
                        "Toque para atribuir ou retirar disciplinas:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val currentNames = subjects.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        availableSubjects.forEach { name ->
                            val on = currentNames.any { TextNorm.sameSubject(it, name) }
                            FilterChip(
                                selected = on,
                                onClick = {
                                    subjects = if (on) {
                                        currentNames.filterNot { TextNorm.sameSubject(it, name) }.joinToString(", ")
                                    } else {
                                        (currentNames + name).joinToString(", ")
                                    }
                                    error = null
                                },
                                label = { Text(name) }
                            )
                        }
                    }
                }
                EditField("Sala", classroom) { classroom = it; error = null }
                ChipRow(listOf("Docente N1", "Docente N2", "Docente N3"), category) { category = it }
                ChipRow(listOf("Efectivo", "Contratado", "Estagiário"), contract) { contract = it }
                ChipRow(listOf("ACTIVO", "LICENÇA", "TRANSFERIDO"), status) { status = it }
                EditField("Biografia", bio, singleLine = false) { bio = it; error = null }
                error?.let { Text(it, color = AcademicRed, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    teacher.copy(
                        fullName = fullName,
                        phone = phone,
                        email = email,
                        mainSubjects = subjects,
                        assignedClassroom = classroom,
                        category = category,
                        contractType = contract,
                        status = status,
                        bio = bio
                    )
                ) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
    ) {
        options.forEach { option ->
            FilterChip(selected = selected == option, onClick = { onSelect(option) }, label = { Text(option) })
        }
    }
}
