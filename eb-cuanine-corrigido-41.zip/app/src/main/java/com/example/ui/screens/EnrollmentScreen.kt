package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TransferWithinAStation
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EnrollmentStatus
import com.example.data.model.Student
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.CaptureFiles
import com.example.util.DocumentOcrParser
import com.example.util.OcrScannerHelper
import com.example.util.PdfExporter
import com.example.util.PrintHelper
import com.example.util.SneCalculator
import java.io.File
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnrollmentScreen(
    students: List<Student>,
    onRegisterStudent: (
        fullName: String,
        birthDate: String,
        gender: String,
        guardianName: String,
        guardianPhone: String,
        address: String,
        gradeClass: Int,
        section: String,
        docType: String,
        docNumber: String,
        photoBitmap: Bitmap?,
        docBitmap: Bitmap?,
        onSuccess: () -> Unit
    ) -> Unit,
    onStudentClick: (Student) -> Unit,
    onDeleteStudent: (Student) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Nova Inscrição, 1: Painel & Alunos Registados
    var statusFilter by remember { mutableStateOf("TODOS") }

    // Formulário States
    var fullName by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("M") }
    var guardianName by remember { mutableStateOf("") }
    var guardianPhone by remember { mutableStateOf("+258 84 ") }
    var address by remember { mutableStateOf("Cuanine, Manhiça") }
    var gradeClass by remember { mutableIntStateOf(1) }
    var section by remember { mutableStateOf("A") }
    var docType by remember { mutableStateOf("BI") }
    var docNumber by remember { mutableStateOf("") }

    var studentPhotoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var docPhotoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var ocrFeedbackMessage by remember { mutableStateOf<String?>(null) }
    var confirmedStudentForCertificate by remember { mutableStateOf<Student?>(null) }

    val scope = rememberCoroutineScope()
    var docPhotoUri by remember { mutableStateOf<Uri?>(null) }

    // Leitura real do documento com Google ML Kit (no dispositivo). Só preenche o que encontrar.
    fun runOcrExtraction(uri: Uri) {
        scope.launch {
            ocrFeedbackMessage = "A ler o documento..."
            try {
                val text = OcrScannerHelper.recognizeDocumentText(context, uri)
                val parsed = DocumentOcrParser.parse(text)
                val filled = mutableListOf<String>()
                parsed.name?.let { fullName = it; filled.add("nome") }
                parsed.birthDate?.let { birthDate = it; filled.add("data de nascimento") }
                parsed.docNumber?.let { docNumber = it; docType = "BI"; filled.add("n.º do BI") }
                parsed.phone?.let { guardianPhone = it; filled.add("contacto") }
                ocrFeedbackMessage = if (filled.isEmpty()) {
                    "Não consegui reconhecer dados neste documento. Tire outra fotografia com boa luz e o documento direito, ou preencha manualmente."
                } else {
                    "Lido por OCR: " + filled.joinToString(", ") + ". Confirme e corrija cada campo antes de matricular."
                }
            } catch (e: Throwable) {
                ocrFeedbackMessage = "Não foi possível ler o documento. Preencha manualmente."
            }
        }
    }

    val studentCameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            studentPhotoBitmap = bitmap
            Toast.makeText(context, "Foto do aluno capturada!", Toast.LENGTH_SHORT).show()
        }
    }

    val docCameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { saved ->
        val uri = docPhotoUri
        if (saved && uri != null) {
            scope.launch {
                val bmp = try {
                    OcrScannerHelper.loadPreviewBitmap(context, uri)
                } catch (e: Throwable) {
                    null
                }
                if (bmp != null) {
                    docPhotoBitmap = bmp
                    Toast.makeText(context, "Documento fotografado! A ler o texto...", Toast.LENGTH_SHORT).show()
                    runOcrExtraction(uri)
                } else {
                    Toast.makeText(context, "Não foi possível abrir a fotografia.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    var docTypeExpanded by remember { mutableStateOf(false) }

    // Estatísticas de Movimentação Escolar (Ciclos de Matrícula)
    val activeCount = students.count { it.enrollmentStatus == "ACTIVO" }
    val transferredCount = students.count { it.enrollmentStatus == "TRANSFERIDO" }
    val droppedCount = students.count { it.enrollmentStatus == "DESISTIDO" }

    val filteredList = remember(students, statusFilter) {
        if (statusFilter == "TODOS") students else students.filter { it.enrollmentStatus == statusFilter }
    }

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Nova Matrícula", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Movimentação & Alunos (${students.size})", fontWeight = FontWeight.Bold) }
            )
        }

        if (selectedTab == 0) {
            // Formulário de Nova Matrícula
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column {
                                Text("Inscrição Oficial e Scanner de Documentos", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Fotografe o aluno e o documento (BI/Cédula) para arquivo offline.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { studentCameraLauncher.launch(null) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (studentPhotoBitmap != null) {
                                    Image(
                                        bitmap = studentPhotoBitmap!!.asImageBitmap(),
                                        contentDescription = "Foto do Aluno",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .border(2.dp, AcademicEmerald, CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (studentPhotoBitmap != null) "✓ Foto Capturada" else "Fotografar Aluno",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (studentPhotoBitmap != null) AcademicGreen else MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    try {
                                        val uri = CaptureFiles.newCaptureUri(context, "documento.jpg")
                                        docPhotoUri = uri
                                        docCameraLauncher.launch(uri)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Não foi possível abrir a câmara.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (docPhotoBitmap != null) {
                                    Image(
                                        bitmap = docPhotoBitmap!!.asImageBitmap(),
                                        contentDescription = "Foto do Documento",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .border(2.dp, AcademicEmerald, RoundedCornerShape(8.dp))
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (docPhotoBitmap != null) "✓ Doc. Fotografado" else "Fotografar BI/Cédula",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (docPhotoBitmap != null) AcademicGreen else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val uri = docPhotoUri
                                if (uri != null) runOcrExtraction(uri)
                                else Toast.makeText(context, "Fotografe primeiro o documento.", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.DocumentScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Extrair Dados via OCR (BI/Cédula)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (ocrFeedbackMessage != null) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = AcademicEmerald.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = AcademicEmerald, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = ocrFeedbackMessage!!,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Nome Completo do Aluno *") },
                        placeholder = { Text("ex: Mateus Alberto Cossa") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_name_input")
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = birthDate,
                            onValueChange = { birthDate = it },
                            label = { Text("Data de Nasc. (AAAA-MM-DD)") },
                            placeholder = { Text("2015-05-20") },
                            singleLine = true,
                            modifier = Modifier.weight(1.3f)
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Sexo:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                FilterChip(
                                    selected = gender == "M",
                                    onClick = { gender = "M" },
                                    label = { Text("Masc") },
                                    modifier = Modifier.weight(1f)
                                )
                                FilterChip(
                                    selected = gender == "F",
                                    onClick = { gender = "F" },
                                    label = { Text("Fem") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                item {
                    Column {
                        Text(
                            text = "Classe e Ciclo de Ingresso (SNE):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(1, 2, 3, 4, 5).forEach { c ->
                                FilterChip(
                                    selected = gradeClass == c,
                                    onClick = { gradeClass = c },
                                    label = { Text("$c.ª") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(6, 7, 8, 9, 10).forEach { c ->
                                FilterChip(
                                    selected = gradeClass == c,
                                    onClick = { gradeClass = c },
                                    label = { Text("$c.ª") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Ciclo: ${SneCalculator.getCycleTitle(SneCalculator.getCycleForGrade(gradeClass))}",
                            fontSize = 11.sp,
                            color = CuanineNavy,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Turma / Seção:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("A", "B", "C").forEach { s ->
                                    FilterChip(
                                        selected = section == s,
                                        onClick = { section = s },
                                        label = { Text(s) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        ExposedDropdownMenuBox(
                            expanded = docTypeExpanded,
                            onExpandedChange = { docTypeExpanded = it },
                            modifier = Modifier.weight(1.2f)
                        ) {
                            OutlinedTextField(
                                value = docType,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Tipo Documento") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = docTypeExpanded) },
                                modifier = Modifier.menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = docTypeExpanded,
                                onDismissRequest = { docTypeExpanded = false }
                            ) {
                                listOf("BI", "Cédula Pessoal", "Certidão de Nascimento").forEach { dt ->
                                    DropdownMenuItem(
                                        text = { Text(dt) },
                                        onClick = {
                                            docType = dt
                                            docTypeExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = docNumber,
                        onValueChange = { docNumber = it },
                        label = { Text("Número do Documento ($docType)") },
                        placeholder = { Text("ex: 110100889922M ou Cédula N.º 458") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = guardianName,
                        onValueChange = { guardianName = it },
                        label = { Text("Nome do Encarregado de Educação *") },
                        placeholder = { Text("ex: Alberto Cossa") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = guardianPhone,
                            onValueChange = { guardianPhone = it },
                            label = { Text("Contacto Telefónico") },
                            placeholder = { Text("+258 84 123 4567") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("Bairro / Residência") },
                            placeholder = { Text("Cuanine, Manhiça") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Button(
                        onClick = {
                            if (fullName.isBlank()) {
                                Toast.makeText(context, "Por favor introduza o nome do aluno.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (guardianName.isBlank()) {
                                Toast.makeText(context, "Por favor introduza o nome do encarregado.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val enrolledSnapshot = Student(
                                studentNumber = "EBC-2026-" + String.format(Locale.US, "%03d", students.size + 1),
                                fullName = fullName,
                                birthDate = birthDate.ifBlank { "2016-01-01" },
                                gender = gender,
                                guardianName = guardianName,
                                guardianPhone = guardianPhone,
                                address = address,
                                cycle = SneCalculator.getCycleForGrade(gradeClass),
                                gradeClass = gradeClass,
                                section = section,
                                docType = docType,
                                docNumber = docNumber
                            )

                            onRegisterStudent(
                                fullName,
                                birthDate.ifBlank { "2016-01-01" },
                                gender,
                                guardianName,
                                guardianPhone,
                                address,
                                gradeClass,
                                section,
                                docType,
                                docNumber,
                                studentPhotoBitmap,
                                docPhotoBitmap
                            ) {
                                confirmedStudentForCertificate = enrolledSnapshot
                                fullName = ""
                                birthDate = ""
                                guardianName = ""
                                docNumber = ""
                                studentPhotoBitmap = null
                                docPhotoBitmap = null
                                ocrFeedbackMessage = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_enrollment_button")
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Confirmar Matrícula do Aluno", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        } else {
            // ================= ABA: PAINEL DE MOVIMENTAÇÃO E ALUNOS =================
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Painel Estatístico de Retenção e Movimentações
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Monitorização de Movimentação Escolar (SNE)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = CuanineNavy
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                StatusStatBox("Activos", "$activeCount", AcademicGreen, Modifier.weight(1f))
                                StatusStatBox("Transferidos", "$transferredCount", GoldAccent, Modifier.weight(1f))
                                StatusStatBox("Desistidos", "$droppedCount", AcademicRed, Modifier.weight(1f))
                            }
                        }
                    }
                }

                // Filtros de Estado
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("TODOS", "ACTIVO", "TRANSFERIDO", "DESISTIDO").forEach { st ->
                            FilterChip(
                                selected = statusFilter == st,
                                onClick = { statusFilter = st },
                                label = { Text(st, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                items(filteredList) { st ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(10.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onStudentClick(st) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                val localBmp = remember(st.photoUri) {
                                    if (st.photoUri != null && File(st.photoUri).exists()) {
                                        BitmapFactory.decodeFile(st.photoUri)
                                    } else null
                                }
                                if (localBmp != null) {
                                    Image(
                                        bitmap = localBmp.asImageBitmap(),
                                        contentDescription = st.fullName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .border(1.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = st.fullName.take(1),
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 16.sp
                                        )
                                    }
                                }

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            text = st.fullName,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        // Badge de Estado
                                        val statusEnum = when (st.enrollmentStatus) {
                                            "DESISTIDO" -> EnrollmentStatus.DESISTIDO
                                            "TRANSFERIDO" -> EnrollmentStatus.TRANSFERIDO
                                            else -> EnrollmentStatus.ACTIVO
                                        }
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(statusEnum.badgeColorHex))
                                                .padding(horizontal = 5.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = statusEnum.label,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${st.studentNumber} • ${st.gradeClass}.ª '${st.section}' (Toque para ver ficha)",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Enc: ${st.guardianName} (${st.guardianPhone})",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val cert = PdfExporter.exportCertificadoMatriculaPdf(context, st)
                                        PdfExporter.shareFile(context, cert)
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Partilhar Declaração",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val cert = PdfExporter.exportCertificadoMatriculaPdf(context, st)
                                        PrintHelper.printPdfDocument(context, cert, "Declaracao_${st.studentNumber}")
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Print,
                                        contentDescription = "Imprimir Declaração",
                                        tint = AcademicEmerald
                                    )
                                }

                                IconButton(
                                    onClick = { onDeleteStudent(st) }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Remover Aluno",
                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal de Sucesso com Opções de Emissão de Certificado/Talão de Matrícula
    val enrolled = confirmedStudentForCertificate
    if (enrolled != null) {
        AlertDialog(
            onDismissRequest = { confirmedStudentForCertificate = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = AcademicGreen,
                    modifier = Modifier.size(40.dp)
                )
            },
            title = {
                Text(
                    text = "Matrícula Concluída com Sucesso!",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "O(A) estudante ${enrolled.fullName} foi matriculado(a) com sucesso na ${enrolled.gradeClass}.ª Classe, Turma '${enrolled.section}'.",
                        fontSize = 13.sp
                    )
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("N.º de Processo: ${enrolled.studentNumber}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CuanineNavy)
                            Text("Encarregado: ${enrolled.guardianName}", fontSize = 12.sp)
                            Text("Contacto: ${enrolled.guardianPhone}", fontSize = 12.sp)
                        }
                    }
                    Text(
                        text = "Deseja emitir imediatamente o comprovativo / declaração oficial de frequência?",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pdf = PdfExporter.exportCertificadoMatriculaPdf(context, enrolled)
                        PrintHelper.printPdfDocument(context, pdf, "Declaracao_${enrolled.studentNumber}")
                        confirmedStudentForCertificate = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy)
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Imprimir")
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(
                        onClick = {
                            val pdf = PdfExporter.exportCertificadoMatriculaPdf(context, enrolled)
                            PdfExporter.shareFile(context, pdf)
                            confirmedStudentForCertificate = null
                        }
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Partilhar")
                    }
                    TextButton(
                        onClick = { confirmedStudentForCertificate = null }
                    ) {
                        Text("Fechar")
                    }
                }
            }
        )
    }
}

@Composable
fun StatusStatBox(title: String, count: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = count, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = title, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = color)
        }
    }
}
