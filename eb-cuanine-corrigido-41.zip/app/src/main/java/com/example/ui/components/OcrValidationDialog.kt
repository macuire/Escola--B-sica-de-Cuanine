package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subject
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.CuanineNavy
import com.example.util.ScannedGradeRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OcrValidationDialog(
    scannedRows: List<ScannedGradeRow>,
    subjects: List<Subject>,
    onConfirm: (subjectId: Long, term: Int) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedSubjectId by remember { mutableStateOf(subjects.firstOrNull()?.id ?: 1L) }
    var selectedTerm by remember { mutableIntStateOf(1) }
    var subjectExpanded by remember { mutableStateOf(false) }

    val rowsCopy = remember(scannedRows) {
        scannedRows.toMutableList()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = null,
                    tint = CuanineNavy,
                    modifier = Modifier.size(26.dp)
                )
                Column {
                    Text(
                        text = "Validação de Notas (OCR da Pauta)",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Confira ou edite as notas extraídas da foto",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Disciplina e Trimestre de destino
                val currentSubject = subjects.find { it.id == selectedSubjectId } ?: subjects.firstOrNull()
                ExposedDropdownMenuBox(
                    expanded = subjectExpanded,
                    onExpandedChange = { subjectExpanded = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = currentSubject?.name ?: "Selecione a Disciplina",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Gravar na Disciplina") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = subjectExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = subjectExpanded,
                        onDismissRequest = { subjectExpanded = false }
                    ) {
                        subjects.forEach { sub ->
                            DropdownMenuItem(
                                text = { Text(sub.name) },
                                onClick = {
                                    selectedSubjectId = sub.id
                                    subjectExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(1, 2, 3).forEach { term ->
                        FilterChip(
                            selected = selectedTerm == term,
                            onClick = { selectedTerm = term },
                            label = { Text("$term.º Trim.") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tabela de Linhas Detectadas (Editável)
                Text(
                    text = "${rowsCopy.size} alunos detectados na imagem:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxWidth().padding(6.dp)) {
                        itemsIndexed(rowsCopy) { index, row ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1.5f)) {
                                        Text(
                                            text = row.studentName,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = row.studentNumber,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    // Campo editável ACS1
                                    var acs1Str by remember(row.id) { mutableStateOf(row.acs1?.toString() ?: "") }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("ACS1", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        BasicTextField(
                                            value = acs1Str,
                                            onValueChange = {
                                                acs1Str = it
                                                row.acs1 = it.toDoubleOrNull()
                                            },
                                            textStyle = TextStyle(fontSize = 12.sp, textAlign = TextAlign.Center),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                            singleLine = true,
                                            modifier = Modifier
                                                .width(42.dp)
                                                .height(28.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 4.dp)
                                        )
                                    }

                                    // Campo editável ACS2
                                    var acs2Str by remember(row.id) { mutableStateOf(row.acs2?.toString() ?: "") }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("ACS2", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        BasicTextField(
                                            value = acs2Str,
                                            onValueChange = {
                                                acs2Str = it
                                                row.acs2 = it.toDoubleOrNull()
                                            },
                                            textStyle = TextStyle(fontSize = 12.sp, textAlign = TextAlign.Center),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                            singleLine = true,
                                            modifier = Modifier
                                                .width(42.dp)
                                                .height(28.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 4.dp)
                                        )
                                    }

                                    // Campo editável AT
                                    var atStr by remember(row.id) { mutableStateOf(row.at?.toString() ?: "") }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("AT", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        BasicTextField(
                                            value = atStr,
                                            onValueChange = {
                                                atStr = it
                                                row.at = it.toDoubleOrNull()
                                            },
                                            textStyle = TextStyle(fontSize = 12.sp, textAlign = TextAlign.Center),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                            singleLine = true,
                                            modifier = Modifier
                                                .width(42.dp)
                                                .height(28.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(selectedSubjectId, selectedTerm)
                },
                colors = ButtonDefaults.buttonColors(containerColor = AcademicGreen),
                modifier = Modifier.testTag("confirm_ocr_grades_button")
            ) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Gravar Notas na Base de Dados")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Descartar")
            }
        }
    )
}
