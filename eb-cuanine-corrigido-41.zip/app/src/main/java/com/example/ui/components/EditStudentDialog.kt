package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Student
import com.example.ui.theme.AcademicRed

/** Edição dos dados pessoais do aluno. A classe/turma e o estado da matrícula mudam-se noutros sítios. */
@Composable
fun EditStudentDialog(
    student: Student,
    onSave: (Student, (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    var fullName by remember(student.id) { mutableStateOf(student.fullName) }
    var birthDate by remember(student.id) { mutableStateOf(student.birthDate) }
    var gender by remember(student.id) { mutableStateOf(student.gender) }
    var guardianName by remember(student.id) { mutableStateOf(student.guardianName) }
    var guardianPhone by remember(student.id) { mutableStateOf(student.guardianPhone) }
    var address by remember(student.id) { mutableStateOf(student.address) }
    var docType by remember(student.id) { mutableStateOf(student.docType) }
    var docNumber by remember(student.id) { mutableStateOf(student.docNumber) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar aluno", fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "${student.studentNumber} • ${student.gradeClass}.ª '${student.section}'",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                EditField("Nome completo", fullName) { fullName = it; error = null }
                EditField("Data de nascimento (AAAA-MM-DD)", birthDate, KeyboardType.Number) {
                    birthDate = it; error = null
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = gender == "M", onClick = { gender = "M" }, label = { Text("Masculino") })
                    FilterChip(selected = gender == "F", onClick = { gender = "F" }, label = { Text("Feminino") })
                }
                EditField("Nome do encarregado", guardianName) { guardianName = it; error = null }
                EditField("Contacto do encarregado", guardianPhone, KeyboardType.Phone) {
                    guardianPhone = it; error = null
                }
                EditField("Morada / Bairro", address) { address = it; error = null }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    listOf("BI", "Cédula Pessoal", "Certidão de Nascimento").forEach { type ->
                        FilterChip(selected = docType == type, onClick = { docType = type }, label = { Text(type) })
                    }
                }
                EditField("N.º do documento", docNumber) { docNumber = it; error = null }
                error?.let {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(it, color = AcademicRed, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    student.copy(
                        fullName = fullName,
                        birthDate = birthDate,
                        gender = gender,
                        guardianName = guardianName,
                        guardianPhone = guardianPhone,
                        address = address,
                        docType = docType,
                        docNumber = docNumber
                    )
                ) { result ->
                    if (result == null) onDismiss() else error = result
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
internal fun EditField(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, fontSize = 12.sp) },
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth()
    )
}
