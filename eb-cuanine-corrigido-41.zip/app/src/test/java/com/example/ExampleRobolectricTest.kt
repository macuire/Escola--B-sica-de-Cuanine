package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("EB Cuanine", appName)
  }

  @Test
  fun `verify sne cycle calculation`() {
    val cycle1 = com.example.util.SneCalculator.getCycleForGrade(1)
    val cycle2 = com.example.util.SneCalculator.getCycleForGrade(4)
    val cycle3 = com.example.util.SneCalculator.getCycleForGrade(10)
    assertEquals(1, cycle1)
    assertEquals(2, cycle2)
    assertEquals(3, cycle3)

    // Formula test: (14 + 16 + 2*15) / 4 = 60 / 4 = 15.0
    val avg = com.example.util.SneCalculator.calculateTermAverage(cycle = 3, acs1 = 14.0, acs2 = 16.0, at = 15.0)
    assertEquals(15.0, avg ?: 0.0, 0.01)
  }

  @Test
  fun `verify teacher entity and sne cycle titles`() {
    val teacher = com.example.data.model.Teacher(
        teacherCode = "DOC-EBC-01",
        fullName = "Prof.ª Helena Cossa",
        gender = "F",
        contractType = "Efectivo",
        category = "Docente N1",
        assignedClassroom = "Sala 1 - Bloco A"
    )
    assertEquals("DOC-EBC-01", teacher.teacherCode)
    assertEquals("Prof.ª Helena Cossa", teacher.fullName)
    assertEquals("Efectivo", teacher.contractType)

    val cycleTitle1 = com.example.util.SneCalculator.getCycleTitle(1)
    val cycleTitle3 = com.example.util.SneCalculator.getCycleTitle(3)
    assertEquals("1.º Ciclo (1.ª e 2.ª Classes)", cycleTitle1)
    assertEquals("3.º Ciclo (6.ª à 10.ª Classes)", cycleTitle3)
  }
}
