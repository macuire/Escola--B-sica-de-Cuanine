package com.example

import com.example.util.TextNorm
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextNormTest {
    @Test
    fun ignoraAcentosEMaiusculas() {
        assertTrue(TextNorm.sameSubject("matematica", "Matemática"))
        assertTrue(TextNorm.sameSubject("LÍNGUA PORTUGUESA", "Língua Portuguesa"))
    }

    @Test
    fun historiaEncaixaEmCienciasSociaisHistoria() {
        assertTrue(TextNorm.sameSubject("História", "Ciências Sociais / História"))
    }

    @Test
    fun palavrasQueNaoSaoDisciplinasNaoEncaixam() {
        assertFalse(TextNorm.sameSubject("Docente", "Matemática"))
        assertFalse(TextNorm.sameSubject("", "Matemática"))
    }
}
