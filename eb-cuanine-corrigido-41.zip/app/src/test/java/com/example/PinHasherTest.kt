package com.example

import com.example.util.PinHasher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PinHasherTest {

    @Test
    fun pinCorrectoVerifica() {
        val salt = PinHasher.newSalt()
        val hash = PinHasher.hash("4821", salt)
        assertTrue(PinHasher.verify("4821", salt, hash))
    }

    @Test
    fun pinErradoNaoVerifica() {
        val salt = PinHasher.newSalt()
        val hash = PinHasher.hash("4821", salt)
        assertFalse(PinHasher.verify("4822", salt, hash))
    }

    @Test
    fun saisDiferentesDaoHashesDiferentes() {
        val a = PinHasher.hash("1234", PinHasher.newSalt())
        val b = PinHasher.hash("1234", PinHasher.newSalt())
        assertNotEquals(a, b)
    }

    @Test
    fun hashNaoContemOPin() {
        val salt = PinHasher.newSalt()
        val hash = PinHasher.hash("987654", salt)
        assertEquals(64, hash.length)
        assertFalse(hash.contains("987654"))
    }
}
