package com.example

import com.example.data.model.FormulaConfig
import com.example.util.SneCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SneCalculatorUnitTest {

    @Test
    fun testCycleCalculationForGrades() {
        // 1.º Ciclo: 1.ª e 2.ª classes
        assertEquals(1, SneCalculator.getCycleForGrade(1))
        assertEquals(1, SneCalculator.getCycleForGrade(2))

        // 2.º Ciclo: 3.ª à 5.ª classes
        assertEquals(2, SneCalculator.getCycleForGrade(3))
        assertEquals(2, SneCalculator.getCycleForGrade(4))
        assertEquals(2, SneCalculator.getCycleForGrade(5))

        // 3.º Ciclo: 6.ª à 10.ª classes
        assertEquals(3, SneCalculator.getCycleForGrade(6))
        assertEquals(3, SneCalculator.getCycleForGrade(7))
        assertEquals(3, SneCalculator.getCycleForGrade(8))
        assertEquals(3, SneCalculator.getCycleForGrade(9))
        assertEquals(3, SneCalculator.getCycleForGrade(10))
    }

    @Test
    fun testCycleTitles() {
        assertEquals("1.º Ciclo (1.ª e 2.ª Classes)", SneCalculator.getCycleTitle(1))
        assertEquals("2.º Ciclo (3.ª à 5.ª Classes)", SneCalculator.getCycleTitle(2))
        assertEquals("3.º Ciclo (6.ª à 10.ª Classes)", SneCalculator.getCycleTitle(3))
    }

    @Test
    fun testQualitativeMentionsCycle1() {
        assertEquals("Muito Bom", SneCalculator.getQualitativeMention(17.5))
        assertEquals("Muito Bom", SneCalculator.getQualitativeMention(16.0))
        assertEquals("Bom", SneCalculator.getQualitativeMention(14.0))
        assertEquals("Bom", SneCalculator.getQualitativeMention(13.5))
        assertEquals("Suficiente", SneCalculator.getQualitativeMention(10.0))
        assertEquals("Suficiente", SneCalculator.getQualitativeMention(11.0))
        assertEquals("Não Suficiente", SneCalculator.getQualitativeMention(9.5))
        assertEquals("Não Suficiente", SneCalculator.getQualitativeMention(4.0))
        assertEquals("Sem Avaliação", SneCalculator.getQualitativeMention(null))
    }

    @Test
    fun testCalculateTermAverageCycle3StandardFormula() {
        // MT = (ACS1 + ACS2 + 2*AT) / 4
        // Example: ACS1 = 12.0, ACS2 = 14.0, AT = 15.0 -> (12 + 14 + 30) / 4 = 56 / 4 = 14.0
        val avg = SneCalculator.calculateTermAverage(
            cycle = 3,
            acs1 = 12.0,
            acs2 = 14.0,
            at = 15.0
        )
        assertEquals(14.0, avg ?: 0.0, 0.001)
    }

    @Test
    fun testCalculateTermAverageCustomFormulaConfig() {
        val customConfig = FormulaConfig(
            cycle = 3,
            cycleName = "3.º Ciclo Personalizado",
            acs1Weight = 1.0,
            acs2Weight = 1.0,
            atWeight = 3.0, // Peso 3 para AT
            minPassGrade = 10.0
        )
        // (10*1 + 10*1 + 15*3) / (1 + 1 + 3) = (10 + 10 + 45) / 5 = 65 / 5 = 13.0
        val avg = SneCalculator.calculateTermAverage(
            cycle = 3,
            acs1 = 10.0,
            acs2 = 10.0,
            at = 15.0,
            config = customConfig
        )
        assertEquals(13.0, avg ?: 0.0, 0.001)
    }

    @Test
    fun testHonorRollEligibility() {
        // Média >= 13.5 e sem negativas
        val qualifyingGrades = listOf(14.0, 16.0, 15.0, 14.5)
        val nonQualifyingGradesLowAvg = listOf(11.0, 12.0, 10.0)
        val nonQualifyingGradesNegative = listOf(18.0, 18.0, 8.0) // média alta, mas tem negativa (8.0)

        val avg1 = qualifyingGrades.average()
        assertTrue(avg1 >= 13.5 && qualifyingGrades.none { it < 10.0 })

        val avg2 = nonQualifyingGradesLowAvg.average()
        assertFalse(avg2 >= 13.5)

        val avg3 = nonQualifyingGradesNegative.average()
        assertTrue(avg3 >= 13.5)
        assertFalse(nonQualifyingGradesNegative.none { it < 10.0 }) // desqualificado por ter nota < 10
    }
}
