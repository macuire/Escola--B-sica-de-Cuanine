package com.example

import com.example.util.DocumentOcrParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DocumentOcrParserTest {

    @Test
    fun leNomeDataNumeroEContacto() {
        val text = """
            REPUBLICA DE MOCAMBIQUE
            Nome: Mateus Alberto Cossa
            Data de Nascimento 12/04/2016
            110200123456M
            Contacto +258 84 1234567
        """.trimIndent()
        val p = DocumentOcrParser.parse(text)
        assertEquals("Mateus Alberto Cossa", p.name)
        assertEquals("2016-04-12", p.birthDate)
        assertEquals("110200123456M", p.docNumber)
        assertEquals("+258 84 1234567", p.phone)
    }

    @Test
    fun nomeNaLinhaSeguinte() {
        val p = DocumentOcrParser.parse("NOME\nLucilia Ernesto Matsinhe\nNascimento: 2015-02-28")
        assertEquals("Lucilia Ernesto Matsinhe", p.name)
        assertEquals("2015-02-28", p.birthDate)
    }

    @Test
    fun textoSemDadosNaoInventaNada() {
        val p = DocumentOcrParser.parse("xxxx ruido 123")
        assertNull(p.name)
        assertNull(p.birthDate)
        assertNull(p.docNumber)
        assertNull(p.phone)
    }
}
