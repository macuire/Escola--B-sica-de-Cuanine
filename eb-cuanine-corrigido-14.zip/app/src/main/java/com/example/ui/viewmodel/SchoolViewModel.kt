package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AccountDatabase
import com.example.data.database.AppDatabase
import com.example.data.model.AttendanceRecord
import com.example.data.model.Classroom
import com.example.data.model.FormulaConfig
import com.example.data.model.GradeRecord
import com.example.data.model.PautaLock
import com.example.data.model.SchoolNotice
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.data.model.Teacher
import com.example.data.model.TeacherBio
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.SchoolRepository
import com.example.util.ColumnMapping
import com.example.util.OcrScannerHelper
import com.example.util.ParsedSheet
import com.example.util.PinHasher
import com.example.util.ScannedGradeRow
import com.example.util.SneCalculator
import com.example.util.SpreadsheetHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SchoolViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val repository = SchoolRepository(db.schoolDao())

    // Perfil Ativo
    private val _currentRole = MutableStateFlow(UserRole.DIRECAO)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    // Alternador Dinâmico de Tema (Modo Claro / Modo Escuro Material 3)
    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    // Indicador Visual de Conectividade (Offline-First)
    private val _isOnline = MutableStateFlow(false)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    // PINs de Segurança
    val directionPin = "1234"
    val teacherPin = "0000"
    val ictPin = "8888"

    // Aluno logado no Portal do Aluno/Encarregado
    private val _loggedInStudent = MutableStateFlow<Student?>(null)
    val loggedInStudent: StateFlow<Student?> = _loggedInStudent.asStateFlow()

    // Dados Principais Reativos
    val allStudents: StateFlow<List<Student>> = repository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allClassrooms: StateFlow<List<Classroom>> = repository.allClassrooms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSubjects: StateFlow<List<Subject>> = repository.allSubjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allGrades: StateFlow<List<GradeRecord>> = repository.allGrades
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFormulaConfigs: StateFlow<List<FormulaConfig>> = repository.allFormulaConfigs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotices: StateFlow<List<SchoolNotice>> = repository.allNotices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPautaLocks: StateFlow<List<PautaLock>> = repository.allPautaLocks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTeachers: StateFlow<List<Teacher>> = repository.allTeachers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Barra de Pesquisa Universal
    private val _universalSearchQuery = MutableStateFlow("")
    val universalSearchQuery: StateFlow<String> = _universalSearchQuery.asStateFlow()

    val searchResults: StateFlow<List<Student>> = _universalSearchQuery
        .debounce(200)
        .flatMapLatest { query ->
            if (query.isBlank()) {
                flowOf(emptyList())
            } else {
                repository.searchStudents(query)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Ficha Completa do Aluno (Clicável em qualquer lista)
    private val _selectedStudentForProfile = MutableStateFlow<Student?>(null)
    val selectedStudentForProfile: StateFlow<Student?> = _selectedStudentForProfile.asStateFlow()

    // Biografia do Professor (Estilo Convite)
    private val _selectedTeacherForBio = MutableStateFlow<TeacherBio?>(null)
    val selectedTeacherForBio: StateFlow<TeacherBio?> = _selectedTeacherForBio.asStateFlow()

    // Diálogo de Lançamento Rápido de Notas
    private val _quickGradeStudent = MutableStateFlow<Student?>(null)
    val quickGradeStudent: StateFlow<Student?> = _quickGradeStudent.asStateFlow()

    // Scanner OCR de Pautas Físicas
    private val _scannedOcrRows = MutableStateFlow<List<ScannedGradeRow>>(emptyList())
    val scannedOcrRows: StateFlow<List<ScannedGradeRow>> = _scannedOcrRows.asStateFlow()

    private val _showOcrDialog = MutableStateFlow(false)
    val showOcrDialog: StateFlow<Boolean> = _showOcrDialog.asStateFlow()

    // Importador de Planilha (CSV/XLSX)
    private val _parsedSpreadsheet = MutableStateFlow<ParsedSheet?>(null)
    val parsedSpreadsheet: StateFlow<ParsedSheet?> = _parsedSpreadsheet.asStateFlow()

    private val _columnMapping = MutableStateFlow(ColumnMapping())
    val columnMapping: StateFlow<ColumnMapping> = _columnMapping.asStateFlow()

    private val _showImportDialog = MutableStateFlow(false)
    val showImportDialog: StateFlow<Boolean> = _showImportDialog.asStateFlow()

    // Data de Assiduidade
    val todayDateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    private val _attendanceDate = MutableStateFlow(todayDateStr)
    val attendanceDate: StateFlow<String> = _attendanceDate.asStateFlow()

    // Feedback Mensagem (Snackbar)
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Biografias Institucionais dos Professores da EB Cuanine
    val teacherBiosList = listOf(
        TeacherBio(
            name = "Prof.ª Helena Cossa",
            title = "Professora do 1.º Ciclo (1.ª Classe)",
            role = "Directora de Turma da 1.ª Classe 'A'",
            room = "Sala 1 - Bloco A",
            experienceYears = 14,
            mainSubjects = "Língua Portuguesa, Matemática e Ed. Visual",
            bio = "Nascida no distrito da Manhiça, dedica-se com carinho e método à alfabetização inicial e ao desenvolvimento psicomotor das crianças na comunidade de Cuanine.",
            welcomeMessage = "Bem-vindos à escola! Aqui cada letra é um passo rumo a um futuro brilhante e cheio de esperança.",
            phone = "+258 84 321 0011"
        ),
        TeacherBio(
            name = "Prof. Carlos Mondlane",
            title = "Professor do 1.º Ciclo (2.ª Classe)",
            role = "Director de Turma da 2.ª Classe 'A'",
            room = "Sala 2 - Bloco A",
            experienceYears = 9,
            mainSubjects = "Língua Portuguesa, Matemática e Ciências Naturais",
            bio = "Graduado pela Universidade Pedagógica, atua com foco em dinâmicas participativas e leitura expressiva nas turmas do ensino básico.",
            welcomeMessage = "Aprender é uma aventura diária. Juntos construímos conhecimento com alegria e disciplina.",
            phone = "+258 86 543 0022"
        ),
        TeacherBio(
            name = "Prof.ª Graça Macamo",
            title = "Professora do 2.º Ciclo (3.ª Classe)",
            role = "Directora de Turma da 3.ª Classe 'A'",
            room = "Sala 3 - Bloco B",
            experienceYears = 12,
            mainSubjects = "Ciências Sociais, Português e Matemática",
            bio = "Especialista em pedagogia primária e coordenadora de projetos comunitários de incentivo ao estudo das raparigas na zona rural de Cuanine.",
            welcomeMessage = "A educação é o maior legado que deixamos aos nossos filhos. Contem sempre comigo nesta caminhada.",
            phone = "+258 82 888 0033"
        ),
        TeacherBio(
            name = "Prof. Américo Nhaca",
            title = "Professor do 3.º Ciclo (8.ª Classe)",
            role = "Delegado da Disciplina de Matemática",
            room = "Sala 8 - Bloco D",
            experienceYears = 16,
            mainSubjects = "Matemática e Física",
            bio = "Reconhecido no distrito pela paixão pelos números e pelo treino de estudantes para as Olimpíadas Nacionais de Matemática.",
            welcomeMessage = "O raciocínio lógico abre as portas do mundo. Nenhum problema é insolúvel quando há determinação.",
            phone = "+258 87 222 0044"
        ),
        TeacherBio(
            name = "Prof. Pedro Munguambe",
            title = "Professor do 3.º Ciclo (10.ª Classe)",
            role = "Director de Turma da 10.ª Classe 'A'",
            room = "Sala 10 - Bloco D",
            experienceYears = 20,
            mainSubjects = "Química, Biologia e Física",
            bio = "Veterano da educação na Manhiça, orienta os alunos finalistas do ensino básico com foco nos exames de certificação do MINEDH.",
            welcomeMessage = "A 10.ª classe é o portal para o ensino médio e técnico. Foco, brio e dedicação integral aos estudos!",
            phone = "+258 84 999 0055"
        )
    )

    init {
        viewModelScope.launch {
            db.seedInitialData()
        }
    }

    // ---------------- Contas, portais de acesso e sessão ----------------
    private val accountDao = AccountDatabase.getInstance(application).accountDao()

    private val _currentAccount = MutableStateFlow<UserAccount?>(null)
    val currentAccount: StateFlow<UserAccount?> = _currentAccount.asStateFlow()

    val allAccounts: StateFlow<List<UserAccount>> = accountDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** null = ainda a carregar; true = ainda não existe nenhum Técnico ICT activo (primeiro acesso). */
    val needsIctSetup: StateFlow<Boolean?> = accountDao
        .observeActiveCountByRole(UserRole.TECNICO_ICT.name)
        .map<Int, Boolean?> { it == 0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private fun normalizePhone(raw: String): String? {
        var digits = raw.filter { it.isDigit() }
        if (digits.startsWith("258") && digits.length == 12) digits = digits.drop(3)
        return if (Regex("^8[2-7]\\d{7}$").matches(digits)) digits else null
    }

    private fun validateCommon(fullName: String, phoneRaw: String, pin: String, pinConfirm: String): String? {
        val name = fullName.trim()
        if (name.length < 5 || name.split(Regex("\\s+")).size < 2) return "Escreva o nome completo."
        if (normalizePhone(phoneRaw) == null) return "Contacto inválido. Use 9 dígitos, por exemplo 84 123 4567."
        if (!Regex("^\\d{4,6}$").matches(pin)) return "O PIN deve ter de 4 a 6 dígitos."
        if (pin != pinConfirm) return "Os dois PINs não coincidem."
        return null
    }

    /** Cadastro de estudante, encarregado, docente ou não docente. Fica PENDENTE até o ICT aprovar. */
    fun registerAccount(
        fullName: String,
        phoneRaw: String,
        accountType: String,
        studentNumber: String,
        jobTitle: String,
        pin: String,
        pinConfirm: String,
        onResult: (String?) -> Unit
    ) {
        viewModelScope.launch {
            val problem = validateCommon(fullName, phoneRaw, pin, pinConfirm)
            if (problem != null) { onResult(problem); return@launch }
            val phone = normalizePhone(phoneRaw) ?: run { onResult("Contacto inválido."); return@launch }
            val isFamily = accountType == "ESTUDANTE" || accountType == "ENCARREGADO"

            var linked: String? = null
            if (isFamily) {
                val student = allStudents.value.find {
                    it.studentNumber.equals(studentNumber.trim(), ignoreCase = true)
                }
                if (student == null) {
                    onResult("N.º de processo do aluno não encontrado. Confirme na secretaria da escola.")
                    return@launch
                }
                linked = student.studentNumber
            } else if (jobTitle.isBlank()) {
                onResult("Indique a função (ex.: Professor de Matemática, Secretaria).")
                return@launch
            }

            if (accountDao.findByPhone(phone) != null) {
                onResult("Já existe uma conta com este contacto.")
                return@launch
            }

            val role = when (accountType) {
                "DOCENTE" -> UserRole.PROFESSOR
                "NAO_DOCENTE" -> UserRole.SECRETARIA
                else -> UserRole.ALUNO_ENCARREGADO
            }
            val salt = PinHasher.newSalt()
            val hash = withContext(Dispatchers.Default) { PinHasher.hash(pin, salt) }
            try {
                accountDao.insert(
                    UserAccount(
                        fullName = fullName.trim(),
                        phone = phone,
                        accountType = accountType,
                        role = role.name,
                        status = "PENDENTE",
                        linkedStudentNumber = linked,
                        jobTitle = jobTitle.trim(),
                        pinSalt = salt,
                        pinHash = hash
                    )
                )
                onResult(null)
            } catch (e: Exception) {
                onResult("Não foi possível guardar o cadastro. Tente novamente.")
            }
        }
    }

    /** Primeiro acesso: cria a conta do Técnico ICT (só enquanto não existir nenhum). */
    fun registerFirstIct(
        fullName: String,
        phoneRaw: String,
        pin: String,
        pinConfirm: String,
        onResult: (String?) -> Unit
    ) {
        viewModelScope.launch {
            val problem = validateCommon(fullName, phoneRaw, pin, pinConfirm)
            if (problem != null) { onResult(problem); return@launch }
            val phone = normalizePhone(phoneRaw) ?: run { onResult("Contacto inválido."); return@launch }
            if (accountDao.countActiveByRole(UserRole.TECNICO_ICT.name) > 0) {
                onResult("Já existe um Técnico ICT. Peça-lhe para aprovar o seu cadastro.")
                return@launch
            }
            if (accountDao.findByPhone(phone) != null) {
                onResult("Já existe uma conta com este contacto.")
                return@launch
            }
            val salt = PinHasher.newSalt()
            val hash = withContext(Dispatchers.Default) { PinHasher.hash(pin, salt) }
            try {
                accountDao.insert(
                    UserAccount(
                        fullName = fullName.trim(),
                        phone = phone,
                        accountType = "NAO_DOCENTE",
                        role = UserRole.TECNICO_ICT.name,
                        status = "ACTIVO",
                        jobTitle = "Técnico ICT",
                        pinSalt = salt,
                        pinHash = hash
                    )
                )
                onResult(null)
            } catch (e: Exception) {
                onResult("Não foi possível criar a conta. Tente novamente.")
            }
        }
    }

    /** portal: "FAMILIA" (estudantes e encarregados) ou "FUNCIONARIOS". Devolve null se entrou, ou a mensagem de erro. */
    fun login(phoneRaw: String, pin: String, portal: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val phone = normalizePhone(phoneRaw)
            if (phone == null || pin.isBlank()) {
                onResult("Introduza o contacto e o PIN.")
                return@launch
            }
            val genericError = "Contacto ou PIN incorrecto."
            val account = accountDao.findByPhone(phone)
            if (account == null) {
                onResult(genericError)
                return@launch
            }
            val now = System.currentTimeMillis()
            if (account.lockedUntil > now) {
                onResult("Muitas tentativas falhadas. Tente novamente dentro de alguns minutos.")
                return@launch
            }
            val ok = withContext(Dispatchers.Default) {
                PinHasher.verify(pin, account.pinSalt, account.pinHash)
            }
            if (!ok) {
                val attempts = account.failedAttempts + 1
                val lock = attempts >= 5
                accountDao.update(
                    account.copy(
                        failedAttempts = if (lock) 0 else attempts,
                        lockedUntil = if (lock) now + 5 * 60 * 1000L else 0L
                    )
                )
                onResult(genericError)
                return@launch
            }
            if ((portal == "FAMILIA") != account.isFamilyAccount) {
                onResult("Esta conta pertence à outra janela. Volte atrás e escolha a janela correcta.")
                return@launch
            }
            when (account.status) {
                "PENDENTE" -> { onResult("O seu cadastro ainda aguarda aprovação do Técnico ICT."); return@launch }
                "ACTIVO" -> Unit
                else -> { onResult("Conta bloqueada. Contacte o Técnico ICT."); return@launch }
            }
            if (account.failedAttempts != 0 || account.lockedUntil != 0L) {
                accountDao.update(account.copy(failedAttempts = 0, lockedUntil = 0L))
            }
            startSession(account)
            onResult(null)
        }
    }

    private fun startSession(account: UserAccount) {
        val role = runCatching { UserRole.valueOf(account.role) }.getOrDefault(UserRole.ALUNO_ENCARREGADO)
        _currentRole.value = role
        _loggedInStudent.value = if (role == UserRole.ALUNO_ENCARREGADO) {
            allStudents.value.find {
                it.studentNumber.equals(account.linkedStudentNumber ?: "", ignoreCase = true)
            }
        } else {
            null
        }
        _currentAccount.value = account
    }

    fun logout() {
        _currentAccount.value = null
        _loggedInStudent.value = null
        _currentRole.value = UserRole.ALUNO_ENCARREGADO // perfil de menor privilégio
        setUniversalSearchQuery("")
    }

    private fun isIctSession(): Boolean =
        _currentAccount.value?.role == UserRole.TECNICO_ICT.name

    private fun isOwnAccount(account: UserAccount): Boolean =
        account.id == _currentAccount.value?.id

    fun approveAccount(account: UserAccount, role: UserRole) {
        if (!isIctSession()) return
        viewModelScope.launch {
            accountDao.update(
                account.copy(status = "ACTIVO", role = role.name, failedAttempts = 0, lockedUntil = 0L)
            )
            _userMessage.value = "Conta aprovada: ${account.fullName} (${role.label})"
        }
    }

    fun setAccountStatus(account: UserAccount, status: String) {
        if (!isIctSession()) return
        if (isOwnAccount(account)) {
            _userMessage.value = "Não pode alterar o estado da sua própria conta."
            return
        }
        viewModelScope.launch {
            accountDao.update(account.copy(status = status, failedAttempts = 0, lockedUntil = 0L))
            _userMessage.value = "Estado actualizado: ${account.fullName}"
        }
    }

    fun changeAccountRole(account: UserAccount, role: UserRole) {
        if (!isIctSession()) return
        if (isOwnAccount(account)) {
            _userMessage.value = "Não pode alterar a função da sua própria conta."
            return
        }
        viewModelScope.launch {
            accountDao.update(account.copy(role = role.name))
            _userMessage.value = "Função actualizada: ${account.fullName} (${role.label})"
        }
    }

    fun resetAccountPin(account: UserAccount, newPin: String, onResult: (String?) -> Unit) {
        if (!isIctSession()) return
        if (!Regex("^\\d{4,6}$").matches(newPin)) {
            onResult("O PIN deve ter de 4 a 6 dígitos.")
            return
        }
        viewModelScope.launch {
            val salt = PinHasher.newSalt()
            val hash = withContext(Dispatchers.Default) { PinHasher.hash(newPin, salt) }
            accountDao.update(
                account.copy(pinSalt = salt, pinHash = hash, failedAttempts = 0, lockedUntil = 0L)
            )
            _userMessage.value = "PIN redefinido: ${account.fullName}"
            onResult(null)
        }
    }

    fun deleteAccount(account: UserAccount) {
        if (!isIctSession()) return
        if (isOwnAccount(account)) {
            _userMessage.value = "Não pode eliminar a sua própria conta."
            return
        }
        viewModelScope.launch {
            accountDao.delete(account)
            _userMessage.value = "Conta eliminada: ${account.fullName}"
        }
    }

    fun setRole(role: UserRole) {
        _currentRole.value = role
    }

    fun toggleDarkTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun toggleNetworkStatus() {
        _isOnline.value = !_isOnline.value
        _userMessage.value = if (_isOnline.value) "Estado de rede: Online (Modo Híbrido)" else "Estado de rede: 100% Offline (Local-First Room)"
    }

    fun setUniversalSearchQuery(query: String) {
        _universalSearchQuery.value = query
    }

    fun openStudentProfile(student: Student) {
        _selectedStudentForProfile.value = student
    }

    fun closeStudentProfile() {
        _selectedStudentForProfile.value = null
    }

    fun openTeacherBio(teacher: TeacherBio) {
        _selectedTeacherForBio.value = teacher
    }

    fun closeTeacherBio() {
        _selectedTeacherForBio.value = null
    }

    fun openQuickGrade(student: Student) {
        _quickGradeStudent.value = student
    }

    fun closeQuickGrade() {
        _quickGradeStudent.value = null
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun postMessage(msg: String) {
        _userMessage.value = msg
    }

    // Governação de Pautas (Lock / Trava Pós-Conselho)
    fun isPautaLocked(gradeClass: Int, section: String, subjectId: Long, term: Int): Boolean {
        return allPautaLocks.value.any {
            it.gradeClass == gradeClass && it.section == section && it.subjectId == subjectId && it.term == term && it.isLocked
        }
    }

    fun lockPauta(gradeClass: Int, section: String, subjectId: Long, term: Int, lockedBy: String = "Conselho de Notas") {
        viewModelScope.launch {
            val lock = PautaLock(
                gradeClass = gradeClass,
                section = section,
                subjectId = subjectId,
                term = term,
                isLocked = true,
                lockedBy = lockedBy,
                lockedAt = System.currentTimeMillis()
            )
            repository.setPautaLock(lock)
            _userMessage.value = "Pauta fechada e bloqueada pelo $lockedBy! Apenas o Técnico ICT pode editar."
        }
    }

    fun unlockPauta(gradeClass: Int, section: String, subjectId: Long, term: Int, reason: String = "Soberania do Técnico ICT") {
        viewModelScope.launch {
            val lock = PautaLock(
                gradeClass = gradeClass,
                section = section,
                subjectId = subjectId,
                term = term,
                isLocked = false,
                lockedBy = "Desbloqueado por TÉCNICO_ICT",
                lockedAt = System.currentTimeMillis(),
                unlockReason = reason
            )
            repository.setPautaLock(lock)
            _userMessage.value = "Soberania ICT: Pauta desbloqueada para edição com sucesso."
        }
    }

    // Assiduidade / Presenças Diárias
    fun markAttendance(studentId: Long, subjectId: Long, status: String, term: Int = 1) {
        viewModelScope.launch {
            val record = AttendanceRecord(
                studentId = studentId,
                subjectId = subjectId,
                date = _attendanceDate.value,
                status = status,
                term = term
            )
            repository.saveAttendance(record)
        }
    }

    // Gestão de Ciclos de Matrícula (Desistidos e Transferidos)
    fun updateStudentEnrollmentStatus(studentId: Long, newStatus: String, transferDest: String? = null, dropReason: String? = null) {
        viewModelScope.launch {
            repository.updateEnrollmentStatus(studentId, newStatus, transferDest, dropReason)
            _userMessage.value = "Estado de matrícula actualizado para '$newStatus'."
            // Atualiza perfil aberto se for o mesmo aluno
            if (_selectedStudentForProfile.value?.id == studentId) {
                _selectedStudentForProfile.value = repository.getStudentByIdDirect(studentId)
            }
        }
    }

    // Login Aluno/Encarregado
    fun loginStudent(studentNumberOrDoc: String, pin: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val student = allStudents.value.find {
                (it.studentNumber.equals(studentNumberOrDoc.trim(), ignoreCase = true) ||
                 it.docNumber.equals(studentNumberOrDoc.trim(), ignoreCase = true)) &&
                it.accessPin == pin.trim()
            }
            if (student != null) {
                _loggedInStudent.value = student
                onResult(true)
            } else {
                onResult(false)
            }
        }
    }

    fun logoutStudent() {
        _loggedInStudent.value = null
    }

    // Salvar Aluno com Foto e Documentos
    fun registerStudent(
        fullName: String,
        birthDate: String,
        gender: String,
        guardianName: String,
        guardianPhone: String,
        address: String,
        gradeClass: Int,
        section: String,
        docType: String,
        docNumber: String,
        photoBitmap: Bitmap?,
        docBitmap: Bitmap?,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            var photoPath: String? = null
            var docPath: String? = null

            val count = allStudents.value.size + 1
            val studentNumber = "EBC-2026-${String.format("%03d", count)}"

            val studentsDir = File(context.filesDir, "students")
            if (!studentsDir.exists()) studentsDir.mkdirs()

            if (photoBitmap != null) {
                val photoFile = File(studentsDir, "photo_${studentNumber}.jpg")
                withContext(Dispatchers.IO) {
                    FileOutputStream(photoFile).use { fos ->
                        photoBitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos)
                    }
                }
                photoPath = photoFile.absolutePath
            }

            if (docBitmap != null) {
                val docFile = File(studentsDir, "doc_${studentNumber}.jpg")
                withContext(Dispatchers.IO) {
                    FileOutputStream(docFile).use { fos ->
                        docBitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos)
                    }
                }
                docPath = docFile.absolutePath
            }

            val cycle = SneCalculator.getCycleForGrade(gradeClass)
            val newStudent = Student(
                studentNumber = studentNumber,
                fullName = fullName.trim(),
                birthDate = birthDate.trim(),
                gender = gender,
                guardianName = guardianName.trim(),
                guardianPhone = guardianPhone.trim(),
                address = address.trim().ifBlank { "Cuanine, Manhiça" },
                cycle = cycle,
                gradeClass = gradeClass,
                section = section,
                docType = docType,
                docNumber = docNumber.trim(),
                photoUri = photoPath,
                docPhotoUri = docPath,
                accessPin = "1234",
                enrollmentStatus = "ACTIVO"
            )

            repository.registerStudent(newStudent)
            _userMessage.value = "Aluno $fullName matriculado com sucesso ($studentNumber)!"
            onSuccess()
        }
    }

    // Salvar ou Atualizar Nota (SNE Automático)
    fun saveGrade(
        studentId: Long,
        subjectId: Long,
        term: Int,
        acs1: Double?,
        acs2: Double?,
        at: Double?,
        exam: Double?,
        qualitative: String?
    ) {
        viewModelScope.launch {
            val student = allStudents.value.find { it.id == studentId }
            val cycle = student?.cycle ?: 1
            val config = repository.getFormulaConfig(cycle)

            // Validação de Trava se o utilizador for Professor
            if (_currentRole.value == UserRole.PROFESSOR && student != null) {
                if (isPautaLocked(student.gradeClass, student.section, subjectId, term)) {
                    _userMessage.value = "Atenção: Esta pauta está FECHADA pelo Conselho de Notas. Apenas o Técnico ICT pode editar."
                    return@launch
                }
            }

            val existing = repository.getGradeDirect(studentId, subjectId, term)
            val calculatedAvg = SneCalculator.calculateTermAverage(cycle, acs1, acs2, at, config)
            val calculatedQual = if (cycle == 1) {
                qualitative ?: SneCalculator.getQualitativeMention(calculatedAvg)
            } else null

            val record = (existing ?: GradeRecord(studentId = studentId, subjectId = subjectId, term = term)).copy(
                acs1 = acs1,
                acs2 = acs2,
                at = at,
                exam = exam,
                qualitative = calculatedQual,
                termAverage = calculatedAvg,
                updatedAt = System.currentTimeMillis()
            )

            repository.saveGrade(record)
            _userMessage.value = "Nota gravada com sucesso!"
        }
    }

    // OCR Pautas Físicas
    fun startOcrScan(imageUri: Uri, gradeClass: Int, section: String) {
        viewModelScope.launch {
            val studentsInClass = allStudents.value.filter {
                it.gradeClass == gradeClass && it.section == section && it.enrollmentStatus == "ACTIVO"
            }
            if (studentsInClass.isEmpty()) {
                _userMessage.value = "Esta turma não tem alunos activos para associar às notas."
                return@launch
            }
            val rows = try {
                OcrScannerHelper.processPaperGradeSheet(
                    context = getApplication(),
                    imageUri = imageUri,
                    knownStudents = studentsInClass
                )
            } catch (e: Throwable) {
                _userMessage.value = "Não foi possível ler a imagem da pauta. Tente outra fotografia com boa luz."
                return@launch
            }
            _scannedOcrRows.value = rows
            _showOcrDialog.value = true
        }
    }

    fun dismissOcrDialog() {
        _showOcrDialog.value = false
        _scannedOcrRows.value = emptyList()
    }

    fun applyOcrGrades(subjectId: Long, term: Int) {
        viewModelScope.launch {
            val rows = _scannedOcrRows.value
            var savedCount = 0

            rows.forEach { row ->
                val sId = row.matchedStudentId ?: allStudents.value.find {
                    it.studentNumber.equals(row.studentNumber, ignoreCase = true) ||
                    it.fullName.contains(row.studentName, ignoreCase = true)
                }?.id

                if (sId != null) {
                    val student = allStudents.value.find { it.id == sId }
                    val cycle = student?.cycle ?: 2
                    val config = repository.getFormulaConfig(cycle)
                    val avg = SneCalculator.calculateTermAverage(cycle, row.acs1, row.acs2, row.at, config)

                    val existing = repository.getGradeDirect(sId, subjectId, term)
                    val gradeRec = (existing ?: GradeRecord(studentId = sId, subjectId = subjectId, term = term)).copy(
                        acs1 = row.acs1 ?: existing?.acs1,
                        acs2 = row.acs2 ?: existing?.acs2,
                        at = row.at ?: existing?.at,
                        exam = row.exam ?: existing?.exam,
                        termAverage = avg,
                        updatedAt = System.currentTimeMillis()
                    )
                    repository.saveGrade(gradeRec)
                    savedCount++
                }
            }

            _showOcrDialog.value = false
            _userMessage.value = "$savedCount notas importadas com sucesso da pauta física!"
        }
    }

    // Importador de Planilha (CSV/XLSX)
    fun loadSpreadsheet(uri: Uri, fileName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val sheet = SpreadsheetHelper.parseSpreadsheet(getApplication(), uri, fileName)
            var mapping = ColumnMapping()
            sheet.headers.forEachIndexed { idx, h ->
                val lh = h.lowercase()
                when {
                    lh.contains("nome") || lh.contains("aluno") -> mapping = mapping.copy(nameColIdx = idx)
                    lh.contains("num") || lh.contains("matr") -> mapping = mapping.copy(numberColIdx = idx)
                    lh.contains("sex") || lh.contains("gen") -> mapping = mapping.copy(genderColIdx = idx)
                    lh.contains("nasc") || lh.contains("data") -> mapping = mapping.copy(birthColIdx = idx)
                    lh.contains("class") -> mapping = mapping.copy(classColIdx = idx)
                    lh.contains("turma") || lh.contains("sec") -> mapping = mapping.copy(sectionColIdx = idx)
                    lh.contains("encarreg") || lh.contains("pai") || lh.contains("mãe") -> mapping = mapping.copy(guardianColIdx = idx)
                    lh.contains("tel") || lh.contains("cel") || lh.contains("cont") -> mapping = mapping.copy(phoneColIdx = idx)
                    lh.contains("doc") || lh.contains("bi") -> mapping = mapping.copy(docNumColIdx = idx)
                }
            }
            _columnMapping.value = mapping
            _parsedSpreadsheet.value = sheet
            _showImportDialog.value = true
        }
    }

    fun updateColumnMapping(mapping: ColumnMapping) {
        _columnMapping.value = mapping
    }

    fun dismissImportDialog() {
        _showImportDialog.value = false
        _parsedSpreadsheet.value = null
    }

    fun confirmSpreadsheetImport(defaultClass: Int, defaultSection: String) {
        val sheet = _parsedSpreadsheet.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val students = SpreadsheetHelper.convertRowsToStudents(
                rows = sheet.rows,
                mapping = _columnMapping.value,
                defaultGradeClass = defaultClass,
                defaultSection = defaultSection
            )
            repository.importStudents(students)
            _showImportDialog.value = false
            _parsedSpreadsheet.value = null
            _userMessage.value = "${students.size} alunos importados com sucesso da planilha!"
        }
    }

    // Editor ICT de Fórmulas e Pesos
    fun updateFormulaConfig(config: FormulaConfig) {
        viewModelScope.launch {
            repository.saveFormulaConfig(config)
            _userMessage.value = "Configurações do ${config.cycleName} atualizadas!"
        }
    }

    // Assiduidade / Presenças Diárias
    fun saveDailyAttendance(
        attendanceMap: Map<Long, String>,
        subjectId: Long,
        date: String = todayDateStr,
        term: Int = 1
    ) {
        viewModelScope.launch {
            val records = attendanceMap.map { (studentId, status) ->
                AttendanceRecord(
                    studentId = studentId,
                    subjectId = subjectId,
                    date = date,
                    status = status,
                    term = term
                )
            }
            if (records.isNotEmpty()) {
                repository.saveAttendances(records)
                _userMessage.value = "Presenças de ${records.size} alunos gravadas para $date!"
            } else {
                _userMessage.value = "Nenhum aluno registado na chamada."
            }
        }
    }

    // Deletar aluno
    fun deleteStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
            _userMessage.value = "Aluno ${student.fullName} removido."
        }
    }
}
