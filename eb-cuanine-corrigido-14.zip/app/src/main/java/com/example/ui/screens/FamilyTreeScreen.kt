package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SupervisorAccount
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Classroom
import com.example.data.model.Student
import com.example.data.model.TeacherBio
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.SneCalculator

@Composable
fun FamilyTreeScreen(
    students: List<Student>,
    classrooms: List<Classroom>,
    teacherBios: List<TeacherBio>,
    onStudentClick: (Student) -> Unit,
    onTeacherClick: (TeacherBio) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCycle by remember { mutableIntStateOf(1) } // 1, 2 ou 3

    val filteredClassrooms = remember(classrooms, selectedCycle) {
        classrooms.filter { it.cycle == selectedCycle }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Cabeçalho do Organograma Institucional
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CuanineNavy),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.AccountTree, contentDescription = null, tint = GoldAccent)
                        Text(
                            text = "Organograma Escolar • Family Tree",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Hierarquia Institucional e Vínculos Familiares: Direcção ➔ Professores ➔ Encarregados ➔ Alunos",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
        }

        // ================= NÍVEL 1: DIRECÇÃO DA ESCOLA =================
        item {
            Text(
                text = "1. Nível de Cúpula: Direcção da Escola Básica de Cuanine",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = CuanineNavy
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TreeLeaderCard(
                    name = "Prof. Alberto Mondlane",
                    role = "Director Geral da Escola",
                    icon = Icons.Default.School,
                    badgeColor = CuanineNavy,
                    modifier = Modifier.weight(1f)
                )
                TreeLeaderCard(
                    name = "Prof.ª Graça Macamo",
                    role = "Directora Pedagógica",
                    icon = Icons.Default.SupervisorAccount,
                    badgeColor = AcademicEmerald,
                    modifier = Modifier.weight(1f)
                )
                TreeLeaderCard(
                    name = "Eng. Octávio Cossa",
                    role = "Técnico ICT & Dados",
                    icon = Icons.Default.Computer,
                    badgeColor = GoldAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Filtro por Ciclo Curricular
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "2. Tronco Pedagógico por Ciclo:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(1, 2, 3).forEach { c ->
                        FilterChip(
                            selected = selectedCycle == c,
                            onClick = { selectedCycle = c },
                            label = { Text("$c.º Ciclo", fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        // ================= NÍVEIS 2, 3 e 4: PROFESSOR -> ENCARREGADO -> ALUNOS =================
        items(filteredClassrooms) { classroom ->
            val classStudents = students.filter { it.gradeClass == classroom.grade && it.section == classroom.section }
            val teacherBio = teacherBios.find { it.name.contains(classroom.classTeacher.replace("Prof.ª ", "").replace("Prof. ", "")) }
                ?: TeacherBio(
                    name = classroom.classTeacher,
                    title = "Director de Turma",
                    role = "Docente Regente da ${classroom.grade}.ª '${classroom.section}'",
                    room = classroom.roomName,
                    experienceYears = 10,
                    mainSubjects = "Currículo Geral do SNE",
                    bio = "Docente empenhado na formação integral e disciplina dos alunos da EB Cuanine.",
                    welcomeMessage = "Contem comigo para o sucesso dos vossos educandos!"
                )

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Nó: Professor / Director de Turma (Clicável para ver Bio estilo Convite)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .clickable { onTeacherClick(teacherBio) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(CuanineNavy),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(20.dp))
                            }
                            Column {
                                Text(
                                    text = classroom.classTeacher,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "Director(a) da ${classroom.grade}.ª Classe '${classroom.section}' (${classroom.roomName})",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Text(
                            text = "Ver Biografia ❯",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Linha Conectora de Hierarquia
                    Row(
                        modifier = Modifier.padding(start = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "│\n└─── Alunos e Encarregados Associados (${classStudents.size}):",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Lista de Alunos e Encarregados
                    Column(
                        modifier = Modifier.padding(start = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        classStudents.forEach { st ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .clickable { onStudentClick(st) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "• ${st.fullName}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "   Encarregado: ${st.guardianName} (${st.guardianPhone})",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "Ficha Completa ❯",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TreeLeaderCard(
    name: String,
    role: String,
    icon: ImageVector,
    badgeColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(badgeColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = name,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1
            )
            Text(
                text = role,
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 2
            )
        }
    }
}
