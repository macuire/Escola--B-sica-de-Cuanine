package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Divider
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserRole
import com.example.ui.components.OcrValidationDialog
import com.example.ui.components.PinAuthDialog
import com.example.ui.components.QuickGradeEntryDialog
import com.example.ui.components.StudentProfileDialog
import com.example.ui.components.TeacherBioDialog
import com.example.ui.components.TopAppBarWithCommand
import com.example.ui.screens.CouncilScreen
import com.example.ui.screens.DirectionScreen
import com.example.ui.screens.EnrollmentScreen
import com.example.ui.screens.FamilyTreeScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IctEditorScreen
import com.example.ui.screens.StudentPortalScreen
import com.example.ui.screens.TeacherScreen
import com.example.data.model.UserAccount
import com.example.ui.screens.AccessGateScreen
import com.example.ui.screens.AccountsAdminScreen
import com.example.ui.screens.TeachersScreen
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.SchoolViewModel
import kotlinx.coroutines.launch

enum class AppNavScreen(val title: String, val icon: ImageVector) {
    HOME("Início (Mural & Honra)", Icons.Default.Newspaper),
    PROFESSORES("Professores", Icons.Default.Badge),
    ORGANOGRAMA("Organograma Escolar", Icons.Default.AccountTree),
    DIRECAO("Painel da Direcção", Icons.Default.Assessment),
    PROFESSOR("Lançamento & Presenças", Icons.Default.Edit),
    MATRICULA("Matrícula & Scanner", Icons.Default.HowToReg),
    PORTAL_ALUNO("Aluno / Encarregado", Icons.Default.School),
    CONSELHO("Conselho de Escola", Icons.Default.Groups),
    CONTAS("Contas & Cadastros (ICT)", Icons.Default.ManageAccounts),
    ICT_EDITOR("Técnico ICT & Soberania", Icons.Default.Build)
}

class MainActivity : ComponentActivity() {

    private val viewModel: SchoolViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
            // Escala compacta: reduz tamanhos de quadros e letras e ignora tamanhos de letra muito grandes do sistema.
            val baseDensity = LocalDensity.current
            CompositionLocalProvider(
                LocalDensity provides Density(
                    density = baseDensity.density * 0.88f,
                    fontScale = minOf(baseDensity.fontScale, 1.0f)
                )
            ) {
                MyApplicationTheme(darkTheme = isDarkTheme) {
                    EBAppContent(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun EBAppContent(viewModel: SchoolViewModel) {
    val currentAccount by viewModel.currentAccount.collectAsStateWithLifecycle()
    val needsIctSetup by viewModel.needsIctSetup.collectAsStateWithLifecycle()
    val account = currentAccount

    if (account == null) {
        AccessGateScreen(
            needsIctSetup = needsIctSetup,
            onLogin = { phone, pin, portal, callback -> viewModel.login(phone, pin, portal, callback) },
            onRegister = { name, phone, type, studentNumber, job, pin, pinConfirm, callback ->
                viewModel.registerAccount(name, phone, type, studentNumber, job, pin, pinConfirm, callback)
            },
            onRegisterFirstIct = { name, phone, pin, pinConfirm, callback ->
                viewModel.registerFirstIct(name, phone, pin, pinConfirm, callback)
            }
        )
    } else {
        SchoolMainContent(viewModel = viewModel, account = account)
    }
}

@Composable
fun SchoolMainContent(viewModel: SchoolViewModel, account: UserAccount) {
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val allAccounts by viewModel.allAccounts.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    val allStudents by viewModel.allStudents.collectAsStateWithLifecycle()
    val allClassrooms by viewModel.allClassrooms.collectAsStateWithLifecycle()
    val allSubjects by viewModel.allSubjects.collectAsStateWithLifecycle()
    val allGrades by viewModel.allGrades.collectAsStateWithLifecycle()
    val allFormulaConfigs by viewModel.allFormulaConfigs.collectAsStateWithLifecycle()
    val allNotices by viewModel.allNotices.collectAsStateWithLifecycle()
    val allPautaLocks by viewModel.allPautaLocks.collectAsStateWithLifecycle()
    val allTeachers by viewModel.allTeachers.collectAsStateWithLifecycle()

    val universalSearchQuery by viewModel.universalSearchQuery.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val quickGradeStudent by viewModel.quickGradeStudent.collectAsStateWithLifecycle()
    val selectedStudentForProfile by viewModel.selectedStudentForProfile.collectAsStateWithLifecycle()
    val selectedTeacherForBio by viewModel.selectedTeacherForBio.collectAsStateWithLifecycle()

    val scannedOcrRows by viewModel.scannedOcrRows.collectAsStateWithLifecycle()
    val showOcrDialog by viewModel.showOcrDialog.collectAsStateWithLifecycle()
    val parsedSpreadsheet by viewModel.parsedSpreadsheet.collectAsStateWithLifecycle()
    val columnMapping by viewModel.columnMapping.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val loggedInStudent by viewModel.loggedInStudent.collectAsStateWithLifecycle()

    // Ecrã inicial padrão: HOME (Mural de Notícias & Carrossel do Quadro de Honra)
    var currentScreen by remember { mutableStateOf(AppNavScreen.HOME) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Ao mudar de sessão volta sempre ao início
    LaunchedEffect(account.id) { currentScreen = AppNavScreen.HOME }

    // Monitorar mensagens de feedback
    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    // Controle de Voltar (Retorna ao HOME)
    BackHandler(enabled = currentScreen != AppNavScreen.HOME) {
        currentScreen = AppNavScreen.HOME
    }

    // Troca de ecrã respeitando as permissões do perfil (ver AccessPolicy)
    fun requestScreenChange(screen: AppNavScreen) {
        coroutineScope.launch { drawerState.close() }
        if (AccessPolicy.canOpen(currentRole, screen)) {
            currentScreen = screen
        } else {
            coroutineScope.launch { snackbarHostState.showSnackbar("Sem permissão para abrir esta área.") }
        }
    }

    // Itens visíveis na gaveta conforme o perfil da conta
    val visibleDrawerScreens = remember(currentRole) { AccessPolicy.allowed(currentRole) }

    // Defesa extra: nunca mostrar um ecrã que o perfil não pode abrir
    val safeScreen = if (AccessPolicy.canOpen(currentRole, currentScreen)) currentScreen else AppNavScreen.HOME

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(310.dp)
            ) {
                // Cabeçalho da Gaveta com Brasão da EB Cuanine
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CuanineNavy)
                        .padding(horizontal = 18.dp, vertical = 24.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(GoldAccent),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.eb_cuanine_logo),
                                    contentDescription = "Emblema EB Cuanine",
                                    modifier = Modifier.size(46.dp).clip(CircleShape)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "EB Cuanine",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Distrito da Manhiça",
                                    fontSize = 12.sp,
                                    color = GoldAccent
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = account.fullName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(GoldAccent.copy(alpha = 0.25f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Perfil: ${currentRole.label}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldAccent
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Perfis e Módulos do Sistema
                visibleDrawerScreens.forEach { screen ->
                    val isSelected = safeScreen == screen
                    NavigationDrawerItem(
                        icon = { Icon(imageVector = screen.icon, contentDescription = null) },
                        label = { Text(screen.title, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        selected = isSelected,
                        onClick = { requestScreenChange(screen) },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            selectedIconColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 2.dp)
                            .testTag("drawer_item_${screen.name.lowercase()}")
                    )
                }

                Spacer(modifier = Modifier.weight(1f))
                NavigationDrawerItem(
                    icon = { Icon(imageVector = Icons.Default.Logout, contentDescription = null) },
                    label = { Text("Terminar sessão") },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { drawerState.close() }
                        viewModel.logout()
                    },
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 2.dp)
                        .testTag("drawer_logout")
                )
                Divider(modifier = Modifier.padding(horizontal = 16.dp))
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "100% Offline • SQLite Room",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CuanineNavy
                    )
                    Text(
                        text = "Província de Maputo - Moçambique",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBarWithCommand(
                    currentRole = currentRole,
                    isDarkTheme = isDarkTheme,
                    onToggleDarkTheme = { viewModel.toggleDarkTheme() },
                    isOnline = isOnline,
                    onToggleNetwork = { viewModel.toggleNetworkStatus() },
                    searchQuery = universalSearchQuery,
                    onSearchQueryChange = { viewModel.setUniversalSearchQuery(it) },
                    searchResults = searchResults,
                    onStudentClick = { student ->
                        viewModel.openStudentProfile(student)
                    },
                    onMenuClick = {
                        coroutineScope.launch { drawerState.open() }
                    },
                    searchEnabled = currentRole != UserRole.ALUNO_ENCARREGADO
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { paddingValues ->
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (safeScreen) {
                    AppNavScreen.HOME -> {
                        HomeScreen(
                            students = allStudents,
                            grades = allGrades,
                            notices = allNotices,
                            teachers = allTeachers,
                            classrooms = allClassrooms,
                            currentRole = currentRole,
                            onStudentClick = { student ->
                                if (currentRole != UserRole.ALUNO_ENCARREGADO) {
                                    viewModel.openStudentProfile(student)
                                }
                            },
                            onNavigateToSection = { section ->
                                when (section) {
                                    "CONSELHO" -> requestScreenChange(AppNavScreen.CONSELHO)
                                    "MATRICULA" -> requestScreenChange(AppNavScreen.MATRICULA)
                                    "ORGANOGRAMA" -> requestScreenChange(AppNavScreen.ORGANOGRAMA)
                                    "PROFESSOR" -> requestScreenChange(AppNavScreen.PROFESSOR)
                                    else -> requestScreenChange(AppNavScreen.DIRECAO)
                                }
                            }
                        )
                    }
                    AppNavScreen.PROFESSORES -> {
                        TeachersScreen(
                            teachers = allTeachers,
                            showContacts = currentRole != UserRole.ALUNO_ENCARREGADO
                        )
                    }
                    AppNavScreen.CONTAS -> {
                        AccountsAdminScreen(
                            accounts = allAccounts,
                            currentAccountId = account.id,
                            onApprove = { target, role -> viewModel.approveAccount(target, role) },
                            onSetStatus = { target, status -> viewModel.setAccountStatus(target, status) },
                            onChangeRole = { target, role -> viewModel.changeAccountRole(target, role) },
                            onResetPin = { target, newPin, callback -> viewModel.resetAccountPin(target, newPin, callback) },
                            onDelete = { target -> viewModel.deleteAccount(target) }
                        )
                    }
                    AppNavScreen.ORGANOGRAMA -> {
                        FamilyTreeScreen(
                            students = allStudents,
                            classrooms = allClassrooms,
                            teacherBios = viewModel.teacherBiosList,
                            onStudentClick = { student ->
                                viewModel.openStudentProfile(student)
                            },
                            onTeacherClick = { teacher ->
                                viewModel.openTeacherBio(teacher)
                            }
                        )
                    }
                    AppNavScreen.DIRECAO -> {
                        DirectionScreen(
                            students = allStudents,
                            classrooms = allClassrooms,
                            subjects = allSubjects,
                            grades = allGrades,
                            onStudentClick = { student ->
                                viewModel.openStudentProfile(student)
                            }
                        )
                    }
                    AppNavScreen.PROFESSOR -> {
                        TeacherScreen(
                            students = allStudents,
                            classrooms = allClassrooms,
                            subjects = allSubjects,
                            grades = allGrades,
                            pautaLocks = allPautaLocks,
                            currentRole = currentRole,
                            onSaveGrade = { studentId, subjectId, term, acs1, acs2, at, exam, qual ->
                                viewModel.saveGrade(studentId, subjectId, term, acs1, acs2, at, exam, qual)
                            },
                            onStudentClick = { student ->
                                viewModel.openStudentProfile(student)
                            },
                            onOcrScanTrigger = { uri, gradeClass, section ->
                                viewModel.startOcrScan(uri, gradeClass, section)
                            },
                            onLockPauta = { gradeClass, section, subjectId, term ->
                                viewModel.lockPauta(gradeClass, section, subjectId, term)
                            },
                            onUnlockPauta = { gradeClass, section, subjectId, term ->
                                viewModel.unlockPauta(gradeClass, section, subjectId, term)
                            },
                            onSaveAttendance = { attendanceMap, subjectId, term ->
                                viewModel.saveDailyAttendance(attendanceMap, subjectId, term = term)
                            }
                        )
                    }
                    AppNavScreen.MATRICULA -> {
                        EnrollmentScreen(
                            students = allStudents,
                            onRegisterStudent = { fullName, birthDate, gender, guardianName, guardianPhone, address, gradeClass, section, docType, docNumber, photo, docPhoto, onSuccess ->
                                viewModel.registerStudent(fullName, birthDate, gender, guardianName, guardianPhone, address, gradeClass, section, docType, docNumber, photo, docPhoto, onSuccess)
                            },
                            onStudentClick = { student ->
                                viewModel.openStudentProfile(student)
                            },
                            onDeleteStudent = { student ->
                                viewModel.deleteStudent(student)
                            }
                        )
                    }
                    AppNavScreen.PORTAL_ALUNO -> {
                        StudentPortalScreen(
                            loggedInStudent = loggedInStudent,
                            allStudents = allStudents,
                            subjects = allSubjects,
                            grades = allGrades,
                            onLogin = { num, pin, callback ->
                                viewModel.loginStudent(num, pin, callback)
                            },
                            onLogout = {
                                if (currentRole == UserRole.ALUNO_ENCARREGADO) {
                                    viewModel.logout()
                                } else {
                                    viewModel.logoutStudent()
                                }
                            }
                        )
                    }
                    AppNavScreen.CONSELHO -> {
                        CouncilScreen(
                            students = allStudents,
                            classrooms = allClassrooms,
                            grades = allGrades
                        )
                    }
                    AppNavScreen.ICT_EDITOR -> {
                        IctEditorScreen(
                            formulaConfigs = allFormulaConfigs,
                            classrooms = allClassrooms,
                            subjects = allSubjects,
                            pautaLocks = allPautaLocks,
                            students = allStudents,
                            onUpdateFormulaConfig = { updated ->
                                viewModel.updateFormulaConfig(updated)
                            },
                            onUnlockPauta = { gradeClass, section, subjectId, term ->
                                viewModel.unlockPauta(gradeClass, section, subjectId, term)
                            },
                            onLockPauta = { gradeClass, section, subjectId, term ->
                                viewModel.lockPauta(gradeClass, section, subjectId, term)
                            },
                            parsedSpreadsheet = parsedSpreadsheet,
                            columnMapping = columnMapping,
                            onUpdateColumnMapping = { mapping ->
                                viewModel.updateColumnMapping(mapping)
                            },
                            onLoadSpreadsheet = { uri, name ->
                                viewModel.loadSpreadsheet(uri, name)
                            },
                            onConfirmImport = { defaultClass, defaultSection ->
                                viewModel.confirmSpreadsheetImport(defaultClass, defaultSection)
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal de Ficha Completa do Aluno (Clicável em todas as listas do app)
    selectedStudentForProfile?.let { student ->
        StudentProfileDialog(
            student = student,
            subjects = allSubjects,
            grades = allGrades,
            currentRole = currentRole,
            onUpdateStatus = { studentId, newStatus, dest, reason ->
                viewModel.updateStudentEnrollmentStatus(studentId, newStatus, dest, reason)
            },
            onDismiss = {
                viewModel.closeStudentProfile()
            }
        )
    }

    // Modal de Biografia Institucional do Professor (Estilo Convite)
    selectedTeacherForBio?.let { teacher ->
        TeacherBioDialog(
            teacher = teacher,
            onDismiss = {
                viewModel.closeTeacherBio()
            }
        )
    }

    // Modal de Lançamento Rápido de Notas
    quickGradeStudent?.let { student ->
        QuickGradeEntryDialog(
            student = student,
            subjects = allSubjects,
            formulaConfigs = allFormulaConfigs,
            onSaveGrade = { subjectId, term, acs1, acs2, at, exam, qual ->
                viewModel.saveGrade(student.id, subjectId, term, acs1, acs2, at, exam, qual)
            },
            onDismiss = {
                viewModel.closeQuickGrade()
            }
        )
    }

    // Modal de Validação das Notas Escaneadas por OCR
    if (showOcrDialog && scannedOcrRows.isNotEmpty()) {
        OcrValidationDialog(
            scannedRows = scannedOcrRows,
            subjects = allSubjects,
            onConfirm = { subjectId, term ->
                viewModel.applyOcrGrades(subjectId, term)
            },
            onDismiss = {
                viewModel.dismissOcrDialog()
            }
        )
    }
}
